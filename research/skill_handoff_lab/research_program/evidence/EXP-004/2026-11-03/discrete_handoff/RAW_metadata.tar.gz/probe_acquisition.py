import sys,json,time
from pathlib import Path
sys.path.insert(0,'research/skill_handoff_lab/tools')
from program_discrete_options import Learner,prior
from program_handoff_acquisition import choose_record
import numpy as np,torch
torch.set_num_threads(2)
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103');f=r/'pairs_random_pair_31301/POOL.json'
if f.exists():
 pool=json.loads(f.read_text());m=Learner.load(r/'pairs_random_pair_31301/MODEL_8.pt');data,_=prior(r.parent/'peg_value_20261103');anchors=[t['s']for t in data if t['stage']==0]
 for mode in ['handoff_update','local_update','ees_pair']:
  i,d=choose_record(m,pool,mode,np.random.default_rng(31301),anchors,{});print(mode,i,d['scores'],d['wall_s'],flush=True);(r/f'PROBE_{mode}.json').write_text(json.dumps(d,indent=2))
else:print('WAITING_POOL')
