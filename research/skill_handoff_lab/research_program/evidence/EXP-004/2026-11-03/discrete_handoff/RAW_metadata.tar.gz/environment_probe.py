import sys,json,platform,subprocess,importlib.metadata as m
from pathlib import Path
import torch
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103')
d=dict(python=sys.version,platform=platform.platform(),torch=torch.__version__,torch_cuda=torch.version.cuda,cuda_available=torch.cuda.is_available(),gpu=torch.cuda.get_device_name(0),versions={},isolation='handoff_offline.sh network unshared, GPU0, all ARES-R worktrees read-only',walltime_note='up to three independent physics processes share one GPU; walltime is measured job time, not isolated latency benchmark')
for n in ['numpy','scipy','sapien','mplib','gymnasium']:
 try:d['versions'][n]=m.version(n)
 except m.PackageNotFoundError:d['versions'][n]='unavailable_metadata'
d['maniskill_commit']=subprocess.check_output(['git','-C','/home/andyee/robot-research/ARES-Skilllab/external/benchmark_scout_20261027/ManiSkill','rev-parse','HEAD'],text=True).strip();(r/'ENVIRONMENT.json').write_text(json.dumps(d,indent=2));print(d)
