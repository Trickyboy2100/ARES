#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
python - <<'PY'
import json,pathlib,time
f=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103/baseline_eval/SCORES.json')
while True:
 try:
  if len(json.loads(f.read_text()))==20:break
 except (OSError,ValueError):pass
 time.sleep(5)
PY
for seed in 31301 31302; do
 for alloc in uniform ees handoff local; do
  bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_frontier_acquisition.py --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/frontier_${alloc}_${seed}" --seed "$seed" --mode "$alloc" > "$r/discrete_handoff_20261103/FRONTIER_${alloc}_${seed}.log" 2>&1
 done
done
