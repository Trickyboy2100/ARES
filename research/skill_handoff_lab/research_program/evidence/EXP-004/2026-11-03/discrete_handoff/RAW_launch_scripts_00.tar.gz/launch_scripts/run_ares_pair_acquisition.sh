#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
for seed in 31301 31302; do
 for alloc in random_pair ees_pair handoff_update local_update; do
  bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_handoff_acquisition.py --root "$r/discrete_handoff_20261103" --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/pairs_${alloc}_${seed}" --seed "$seed" --mode "$alloc" > "$r/discrete_handoff_20261103/PAIRS_${alloc}_${seed}.log" 2>&1
 done
done
