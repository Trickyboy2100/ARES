#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
python - <<'PY'
import pathlib,time
r=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103')
while not(r/'frontier_policy_31302/FINAL.pt').exists():time.sleep(5)
PY
for seed in 31301 31302; do
 bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_discrete_handoff.py --mode online --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/mature_policy_${seed}" --seed "$seed" --allocation policy --episodes 128 --train-start 751000 --train-count 64 --eval-every 32 > "$r/discrete_handoff_20261103/MATURE_${seed}.log" 2>&1
 done
