#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
python - <<'PY'
import pathlib,time
r=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103')
while not(r/'pairs_local_update_31302/FINAL.pt').exists():time.sleep(5)
PY
for seed in 31301 31302; do
 for alloc in independent_kernel joint; do
  bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_frontier_acquisition.py --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/frontier_${alloc}_${seed}" --seed "$seed" --mode "$alloc" > "$r/discrete_handoff_20261103/FRONTIER_${alloc}_${seed}.log" 2>&1
 done
done
