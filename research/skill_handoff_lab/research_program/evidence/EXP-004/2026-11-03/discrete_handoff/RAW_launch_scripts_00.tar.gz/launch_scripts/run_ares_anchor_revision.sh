#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
for seed in 31301 31302; do
 bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_frontier_acquisition.py --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/frontier_current_${1}_${seed}" --mode "$1" --seed "$seed" --anchors current_only > "$r/discrete_handoff_20261103/CURRENT_${1}_${seed}.log" 2>&1
done
