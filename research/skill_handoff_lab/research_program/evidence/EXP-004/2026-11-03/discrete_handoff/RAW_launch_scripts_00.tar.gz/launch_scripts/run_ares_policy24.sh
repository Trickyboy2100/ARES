#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
python - <<'PY'
import pathlib,time
f=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103/online_handoff_31302/FINAL.pt')
while not f.exists():time.sleep(5)
PY
for seed in 31301 31302; do
 bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_frontier_acquisition.py --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/frontier_policy_${seed}" --seed "$seed" --mode policy > "$r/discrete_handoff_20261103/FRONTIER_policy_${seed}.log" 2>&1
done
