#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
for seed in 31301 31302; do
 for alloc in policy uniform uncertainty practice handoff; do
  bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_discrete_handoff.py --mode online --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/online_${alloc}_${seed}" --seed "$seed" --allocation "$alloc" --episodes 32 > "$r/discrete_handoff_20261103/ONLINE_${alloc}_${seed}.log" 2>&1
 done
done
