#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103
python - <<'PY'
import pathlib,time,json
r=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103')
p=r/'expansion_eval/SCORES.json'
while True:
 try:
  if p.exists() and len(json.loads(p.read_text()))==60:break
 except json.JSONDecodeError:pass
 time.sleep(5)
PY
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
for script in analyze_discrete_handoff audit_handoff_controls analyze_option_decisions; do
 "$py" "research/skill_handoff_lab/tools/${script}.py" --root "$r" > "$r/${script}.log" 2>&1
done
"$py" research/skill_handoff_lab/tools/audit_option_training_replay.py --root "$r" --prior /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/peg_value_20261103 > "$r/TRAINING_REPLAY_FINAL.log" 2>&1
"$py" research/skill_handoff_lab/tools/summarize_handoff_results.py --root "$r" > "$r/SUMMARIZE.log" 2>&1
while [ ! -f "$r/video_learning/MANIFEST.json" ]; do sleep 5; done
"$py" research/skill_handoff_lab/tools/build_discrete_handoff_review.py --root "$r" > "$r/REVIEW_BUILD.log" 2>&1
touch "$r/ANALYSIS_COMPLETE"
