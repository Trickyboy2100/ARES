#!/bin/bash
set -euo pipefail
r=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004
python - <<'PY'
import pathlib,time
r=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103')
while not all((r/f'frontier_{m}_{s}/FINAL.pt').exists() for m in ['uniform','ees','handoff','local','policy']for s in [31301,31302]):time.sleep(5)
PY
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/eval_handoff_expansion.py --root "$r/discrete_handoff_20261103" --prior "$r/peg_value_20261103" --out "$r/discrete_handoff_20261103/expansion_eval" > "$r/discrete_handoff_20261103/EXPANSION.log" 2>&1
