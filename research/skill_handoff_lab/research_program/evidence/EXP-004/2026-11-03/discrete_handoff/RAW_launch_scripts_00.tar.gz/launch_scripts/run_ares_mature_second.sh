#!/bin/bash
set -euo pipefail
python - <<'PY'
import pathlib,time
p=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103/frontier_policy_31302/FINAL.pt')
while not p.exists():time.sleep(5)
PY
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_discrete_handoff.py --mode online --prior /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/peg_value_20261103 --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103/mature_policy_31302 --seed 31302 --allocation policy --episodes 128 --train-start 751000 --train-count 64 --eval-every 32 > /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103/MATURE_31302.log 2>&1
