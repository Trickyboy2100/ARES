import json,subprocess,pathlib,time
r=pathlib.Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/discrete_handoff_20261103')
while not(r/'frontier_joint_31302/FINAL.pt').exists():time.sleep(5)
for run,pair,out,title in [('frontier_independent_kernel_31301','pair3','video_handoff','Same prefix: measured attachment rescues scene751000'),('frontier_ees_31301','pair0','video_learning','Same prefix: measured attachment degrades scene751002')]:
 rows=json.loads((r/run/'physics/RESULTS.json').read_text());paths=[next(x['path']for x in rows if x['tag']==pair+'_'+str(b))for b in [0,1]]
 cmd=['bash','research/skill_handoff_lab/tools/handoff_offline.sh','/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python','research/skill_handoff_lab/tools/render_peg_skill_pair.py','--left',paths[0],'--right',paths[1],'--out',str(r/out),'--left-title','Identical grasp | original terminal target','--right-title','Identical prefix | actual attachment target','--comparison-title',title]
 with open(r/(out+'.log'),'w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
