#!/bin/bash
set -euo pipefail
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_sac_32201.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_sac_32202.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_supervised_32201.sh
