#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/evaluate_rule_gate.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/confirm_old_rl --model /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/rule_option_20261105/v2_stopping_rl_31801/CHECKPOINT_64.pt --start 765600 --count 32
