#!/bin/bash
set -euo pipefail
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_actor_front_meanq_rear.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_meanq_front_actor_rear.sh
