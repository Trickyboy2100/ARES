#!/bin/bash
set -euo pipefail
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_warm.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_rule.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_old_rl.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_confirm_chart_state_32201.sh
