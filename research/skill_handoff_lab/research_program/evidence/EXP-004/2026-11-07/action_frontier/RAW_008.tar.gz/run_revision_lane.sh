#!/bin/bash
set -euo pipefail
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_sac_support.sh
bash /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/run_chart_state_32201.sh
