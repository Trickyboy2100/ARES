#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/evaluate_full_option.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/confirm_warm --mode warm --start 765600 --count 32
