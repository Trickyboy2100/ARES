import torch,json,hashlib
from pathlib import Path
torch.set_num_threads(2);r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107');names=['sac_32201','factor_32201','supervised_32201','chart_state_32201','sac_32202'];ds={n:torch.load(r/n/'INITIAL.pt',weights_only=False)for n in names};ref=ds[names[0]];out={}
for name,d in ds.items():
 out[name]=dict(sha=hashlib.sha256((r/name/'INITIAL.pt').read_bytes()).hexdigest(),actor_hidden_equal_first=torch.equal(ref['actor']['0.weight'],d['actor']['0.weight']),critic_equal_first=all(torch.equal(ref['q'][k],d['q'][k])for k in ref['q']),zero_actor_output=bool((d['actor']['2.weight']==0).all()))
assert not out['sac_32202']['actor_hidden_equal_first'] and not out['sac_32202']['critic_equal_first']
assert all(out[n]['critic_equal_first']for n in names[:-1]);(r/'ACTUAL_INITIALIZATIONS.json').write_text(json.dumps(out,indent=2));print(out)
