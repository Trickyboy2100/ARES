import sys,json,torch,numpy as np,itertools
from pathlib import Path
sys.path.insert(0,'research/skill_handoff_lab/tools')
from train_target_chart_option import Learner
from program_rule_option import Assets
torch.set_num_threads(2);root=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107');rows=sum([json.load(open(f))for f in root.glob('design_*/RESULTS.json')],[]);model=Learner(Assets(),32201);ids=[1,2,3,4,5,8,9,10,11];pairs=[]
for seed in sorted({r['seed']for r in rows}):
 rs={i:next(r for r in rows if r['seed']==seed and r['label']==f'a{i}')for i in ids};s=rs[1]['entry']['obs'];matrix=model.matrix([s])[0].numpy()
 for i,j in itertools.combinations(ids,2):
  weight=float((matrix[i+1,j+1]+matrix[j+1,i+1])/2);pairs.append(dict(seed=seed,actions=[i,j],weight=weight,outcomes=[rs[i]['success'],rs[j]['success']],opposite=rs[i]['success']!=rs[j]['success']))
w=np.array([x['weight']for x in pairs]);y=np.array([x['opposite']for x in pairs],float);strong=sorted([x for x in pairs if x['opposite']],key=lambda x:-x['weight'])[:12];out=dict(n_pairs=len(pairs),n_scene_clusters=16,unweighted_opposite_fraction=float(y.mean()),coupling_weighted_opposite_fraction=float((w*y).sum()/w.sum()),strongest_conflicting_pairs=strong,scope='design-only within-state pair audit, clustered by16scenes; not576 independent scenes, not current-policy value labels; target closeness is not contact/trajectory equality')
(root/'TARGET_CHART_PHYSICAL_COUNTEREXAMPLES.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
