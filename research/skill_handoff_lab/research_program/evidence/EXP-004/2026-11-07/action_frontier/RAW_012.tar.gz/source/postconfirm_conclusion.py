from pathlib import Path
import json,gzip
lab=Path('/home/andyee/robot-research/ARES-Skilllab');d=lab/'runs/research_program/EXP-004/action_frontier_20261107';rp=lab/'repos/ARES-SCI-program/research/skill_handoff_lab/research_program';e=rp/'evidence/EXP-004/2026-11-07/action_frontier'
s=json.loads((d/'LEARNING_SUMMARY.json').read_text());g=s['groups'];rows=[];effects={}
for seed in [32201,32202]:
 full=g[f'confirm_sac_{seed}'];restricted=g[f'postconfirm_sac_{seed}_support'];assert full['n']==restricted['n']==32
 b,o=restricted['outcomes'],full['outcomes'];gain=[x for x in b if o[x]and not b[x]];loss=[x for x in b if b[x]and not o[x]]
 br={x['seed']:x for x in json.loads((d/f'postconfirm_sac_{seed}_support/RESULTS.json').read_text())};fr={x['seed']:x for x in json.loads((d/f'confirm_sac_{seed}/RESULTS.json').read_text())};pairs={}
 for st in gain+loss:
  k=int(st);ds=[json.load(gzip.open(z[k]['path'],'rt'))for z in [br,fr]];prefix=0
  if ds[0]['initial']==ds[1]['initial']:
   for a,bv in zip(ds[0]['steps'],ds[1]['steps']):
    if any(a[f]!=bv[f]for f in ['q','qvel','tcp','peg','action']):break
    prefix+=1
  pairs[st]=dict(exact_physical_prefix=prefix,restricted=br[k],full=fr[k])
 effects[str(seed)]=dict(full=full['success'],restricted=restricted['success'],full_only=gain,restricted_only=loss,pairs=pairs)
 rows.append(f"| {seed} | {full['success']}/32 | {restricted['success']}/32 | {', '.join(gain)or'none'} | {', '.join(loss)or'none'} |")
(d/'POSTCONFIRM_SUPPORT_EFFECT.json').write_text(json.dumps(dict(scope='Post-hoc frozen-policy support ablation; no retrained restricted learner or global impossibility claim',effects=effects),indent=2))
section='''\n\n## Post-confirmation mechanism check: deployed action support\n\nBoth frozen SAC seeds are reexecuted on all32 now-seen confirmation scenes with only current historical proposal physical IDs plus rule allowed. No model, horizon, reward, planner or initial state changes. These64 additional native episodes test execution dependence, not new independent generalization or a retrained restricted-learning comparison.\n\n| Network seed | Full catalogue | Old proposal support | Full-only successful scenes | Restricted-only successful scenes |\n|---|---:|---:|---|---|\n'''+ '\n'.join(rows)+'''\n\nThe full-policy benefits and regressions must both be retained. Any full-only success supports necessity of the extra executed choices for this frozen policy on that state, not impossibility of every other old-support policy. This does not turn the failed coordinate candidates into an independent algorithm contribution. Exact physical prefixes, raw paths and complete boundary events are in POSTCONFIRM_SUPPORT_EFFECT.json.\n'''
for p in [e/'README.md',rp/'paper/MANUSCRIPT.md',rp/'DECISIONS.md',rp/'EVIDENCE_LEDGER.md',rp/'experiments/EXP-004_EFFECT_CONDITIONED_METHOD.md']:
 p.write_text(p.read_text()+section)
p=rp/'STATE.json';v=json.loads(p.read_text());v['action_frontier_20261107']['posthoc_support_effect']={k:{f:x[f]for f in ['full','restricted','full_only','restricted_only']}for k,x in effects.items()};p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{f:x[f]for f in ['full','restricted','full_only','restricted_only']}for k,x in effects.items()},indent=2))
