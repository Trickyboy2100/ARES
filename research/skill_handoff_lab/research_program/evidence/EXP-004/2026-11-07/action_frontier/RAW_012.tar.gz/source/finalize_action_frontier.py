from pathlib import Path
import json,hashlib,shutil
lab=Path('/home/andyee/robot-research/ARES-Skilllab');repo=lab/'repos/ARES-SCI-program';rp=repo/'research/skill_handoff_lab/research_program';d=lab/'runs/research_program/EXP-004/action_frontier_20261107';e=rp/'evidence/EXP-004/2026-11-07/action_frontier'
assert not(e/'README.md').exists(), 'Do not append the release twice'
s=json.loads((d/'LEARNING_SUMMARY.json').read_text());g=s['groups'];cs=[k for k in g if k.startswith('confirm_')];assert len(cs)==7 and all(g[k]['n']==32 for k in cs)
def row(k,ref):
 v=g[k];b=g[ref]['outcomes'];o=v['outcomes'];return f"| {k} | {v['success']}/{v['n']} | {sum(o[x]and not b[x]for x in b)} | {sum(b[x]and not o[x]for x in b)} | {v['planning_queries']} |"
def table(keys,ref):return '| Fixed policy | Native success | Rescue | Regression | Planner calls |\n|---|---:|---:|---:|---:|\n'+'\n'.join(row(k,ref)for k in keys)
dev=['sac_32201@0','dev_rule','dev_old_rl','dev_fixed5','sac_32201@128','sac_32202@128','factor_32201@128','chart_state_32201@128','supervised_32201@128']
ct=table(sorted(cs),'confirm_warm');dt=table(dev,'sac_32201@0');cost=s['cost'];tr=s['learning']
curves='| Learner | 0 | 32 | 64 | 128 | Own train successes | Actual decisions | Updates | Own planning calls |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|\n'
for k,v in tr.items():curves+=f"| {k} | "+' | '.join(str(g[k+'@'+str(c)]['success'])+'/24'for c in [0,32,64,128])+f" | {v['success']}/128 | {v['effective_decisions']} | {v['updates']} | {v['planning_queries']} |\n"
text=f'''# Action frontier → own-policy joint Option learning

基点c50123e；原生PegInsertionSide-v1/100步/真实抓持/共享强规划器。训练与物理结果已实际完成，非计划。所有本轮新自然场景均为设计、训练或开发确认，未开启封存测试。

[打开完整审查页](REVIEW.html) · [论文/源码对照](PRIOR_ART.md) · [机制与反例](THEORY.md) · [完整复算](LEARNING_SUMMARY.json) · [原始归档与逐文件SHA](RAW_MANIFEST.json)

## 本轮实质推进

1. 256次原生重执行：16个新设计初态，前段三抓持、后段完整现有物理Option。Warm8/16、设计集最佳固定localZ−12/16、有限实测成功并集14/16。只有2例超出最佳固定，不是6例独立方法空间，更不是可部署oracle。
2. 扩展共享执行接口，完成5个128回合own-policy训练：普通SAC两个真正独立网络种子、固定参考/偏移坐标候选、状态相关实际目标坐标修订、同信息终局监督评分。640次真实在线训练；每臂另消费同一256回合设计replay，不能算零数据成本。每臂5120次更新；不是旧transition改名。
3. 固定坐标候选20/24未超普通SAC21/24；根据同方向跨参考成败反转修改Actor坐标，使动作关系由实际目标几何决定，再训练128回合，仅19/24。两次假设均有真实梯度训练、行为与负结果，不继续无依据扩训。
4. 普通SAC两种子均21/24、相同两次救回且无退化。新32自然初态用冻结final128确认如下，未按确认结果选checkpoint。

## 新自然条件的冻结确认

{ct}

基准为同初态warm；两个网络在相同32场景上评价，不能当64独立场景。历史oldRL有不同历史训练预算，只是保留资产对照；不将其分差解释为等预算因果收益。所有新方法共享执行权限/观测/控制器/原生终止标准；各自采集自身数据。冻结rule不在本轮调规则。完整配对场景及描述性bootstrap区间见JSON；小样本不作总体安全保证。

## 固定开发集与真实学习曲线

{dt}

{curves}

765400–423在本轮研究中已看，仅为开发。新确认765600–631在所有模型冻结后才打开，不是封存测试。设计765000–015、own-training765100–227，历史及保留seed碰撞核对见SEED_CHECK。各方法的探索行为分数与贪心部署分数分开。

## 机制证据与被排除的解释

- 同signed Y+换active/refreshed参考，10/16成败反转；Z−为12/16。参考含实际附着/目标重建，不是已证实的3mm数值放大。413个返回规划目标的坐标推导误差≤4.36e−8m；另1次路径参数化失败保留。几何正确不保证学习收益。
- 状态坐标修订的核加权相反结果比例.258，均匀.385；576动作对来自16场景，不是576独立物理条件。这项proxy改善没有变成完整任务优势。
- 765416相同物理前缀68步：普通SAC选择localY+并成功，修订选择rule0、错过必要早期修正而失败。失败不只是“最后动作太多”。
- 765423同前缀71步：SAC的localY+成功；历史oldRL也救回，不能称独占新能力。765402在93步已经成功，94步Z−不记为救回原因。
- 将普通SAC最终策略限制到历史提议支持，仍21/24；213个实际边界也满足旧Gate更严格mask。因此新动作目录有物理机会，但当前开发提升并未证明必须依靠扩大后的部署权限。不是限制接口重新训练的对照。
- 冻结同一SAC模型：Actor21/24；全Mean-Q13/24；只换后段Mean-Q13/24；只换前段Mean-Q19/24。后段提取失配足以造成8次退化。Q是含shaped reward/熵的策略价值，不是成功概率；贪心提取也改变后续分布，不能仅称数值校准误差。
- 三抓持在训练中均有实际选择，但固定grasp设计7/8/7、并集9；765010换抓持本身可救回。没有证明必须联合改变前后参数的协同收益。

## 算法与近邻边界

普通离散SMDP-SAC、成功BC、受控探索、完整Option与Mean-Q都是成熟构件。实际Option持续时间入replay，gamma=1；熵按决策计，不宣称时间划分不变性。候选仅修改Actor residual-logit坐标；固定矩阵和state kernel不是已证实的新算法。状态核改变有限网络函数类，虽参数数相等，不能声称全局表达类相同。

已读PEARL/ViSkill/PolicyDecorator/AGILE公开源码，MP-DQN/ActionBranching/ActionRepresentations等原论文；确切SHA、许可证情况和借鉴边界在PRIOR_ART。AGILE已有状态相关动作关系，因此一般“根据状态共享动作”不能作为原创。没有新STAP官方任务排行榜或此目录完整STAP移植比较，不宣称胜过它。

## 可进入论文的内容与下一项实验

可以进入Method：真实前驱—SkillResult—后继Option接口、数据/恢复/成本定义和两种可反证坐标机制。可以进入Experiments：上述机会矩阵、真实在线曲线、固定确认、参考反转、策略提取消融和失败视频。独立候选优势仍未成立；不把基础设施或监督预热计作原创。

下一项应并列保留预热、历史RL、普通SAC与完整Option，按逐场景证据确定参照，而非继续扩训坐标核：从其冻结策略在新确认中剩余失败/退化，检验后段合法动作价值与实际续接匹配。首先在新的训练初态、共同实际前缀下检验Actor选择和Q偏好是否对应不同Option完成合同；若数据支持，再做同信息、同预算的策略一致改进。已有Mean-Q单独提取失败不能自动证明任一新损失有效。前驱真实作用继续保留，但不扩大没有联合增量证据的抓持网格。

## 成本、原始材料与复现

本轮唯一原生执行 **{cost['unique_native_episodes']}回合/{cost['physical_steps']}物理步/{cost['planning_queries']}规划调用**。规划累计{cost['planner_wall_s']:.3f}s，仿真回合累计{cost['summed_episode_wall_s']:.1f}s；并发运行，不能当实际墙钟历时。网络优化CPU，PhysX单张3080。GPU峰值本轮未连续测量，不用快照冒充峰值。两次采样启动故障200步计入，未进入有效学习；每一原始文件的final官方success与100步已复算。

原始运行目录：`{d}`。发布RAW_*.tar.gz包含完整新模型/优化器/RNG/replay/START事务/训练评测轨迹/运行脚本/日志/源码快照；RAW_MANIFEST逐成员与归档SHA已回读核验。保留CURRENT和0/32/64/128检查点。历史模型由GLOBAL_ASSET_MANIFEST和既有发布证据定位，不能当本轮新训练。未执行的static-chart及额外factor/supervised种子脚本只是预备入口，不计为完成。

复算：仓库tools/analyze_full_option_learning.py --root RUN；plot_full_frontier.py --root RUN --out FIGURES；analyze_full_option_rescues.py；review_full_option.py。原生重跑采用归档run_*.sh和已有隔离handoff_offline.sh；不要对已有输出目录覆盖重跑。训练完整事务resume已测，精确随机状态与优化器续接对齐。

两组视频：[正例RAW](video_765423/RAW.mp4)、[英文标注](video_765423/ANNOTATED.mp4)、[逐帧曲线](video_765423/SYNC_VIEWER.html)；[负例RAW](video_765416/RAW.mp4)、[英文标注](video_765416/ANNOTATED.mp4)、[逐帧曲线](video_765416/SYNC_VIEWER.html)。均为101帧已测状态重放，零新增物理，不作为第二次成功证据。每张科学图另存PNG/PDF。

初始化勘误：历史31901/31902因Gate重设Torch种子而初始网络相同，仅探索种子不同。本轮在加载后重设种子，实际checkpoint验证32201/32202 hidden/Q不同；历史分数全部保留。
'''
(e/'README.md').write_text(text)
summary='; '.join(f"{k.removeprefix('confirm_')} {g[k]['success']}/32"for k in sorted(cs))
section=f'''\n\n## 2026-11-07 completed action-frontier learning cycle\n\nFive128-episode own-policy learners (640 total) follow256 shared native design executions. Two genuinely independent ordinary SAC networks reach21/24 on development; fixed reference/offset coordinates20, state-conditioned target chart19, terminal supervised scoring16. The actual state-chart revision is trained, not merely proposed. Frozen new natural confirmation: {summary}. Fixed final128 selection, no tuning after confirmation; native100 and official success unchanged.\n\n{ct}\n\nEach comparison keeps real grasp, queue, Option termination and physical budget. Shared design cost is charged to each consuming learner; prior models have separately pinned historical budgets. Total cycle {cost['unique_native_episodes']} native episodes/{cost['physical_steps']}steps/{cost['planning_queries']}queries; all positive/negative models and raw physics retained.\n\nThe fixed catalogue has measured design union14/16 versus best fixed12 and warm8, but the learned21/24 remains21 when restricted to old proposals. Catalogue opportunity does not establish deployment dependence. State-conditioned kernel sharing has mature AGILE/action-representation precedents and no independent gain here. Frozen SAC Actor21, rear-only Mean-Q13, front-only Mean-Q19 isolate a deployment extraction problem without proving a particular replacement algorithm. No claim of joint synergy or STAP superiority. An83-dimensional observation and Option durations do not establish a Markov state or a policy-improvement theorem.\n\nEvidence: [action_frontier/README](../evidence/EXP-004/2026-11-07/action_frontier/README.md). Next study should inherit ordinary SAC and investigate policy-consistent executed Option value on fresh training prefixes, not expand unsupported coordinate-sharing networks.\n'''
for rel in ['experiments/EXP-003_STRONG_RL_BASELINES.md','experiments/EXP-004_EFFECT_CONDITIONED_METHOD.md']:
 p=rp/rel;p.write_text(p.read_text()+section)
for rel in ['DECISIONS.md','EVIDENCE_LEDGER.md']:
 p=rp/rel;p.write_text(p.read_text()+section.replace('../evidence/','evidence/'))
p=rp/'PAPER_CONTRACT.md';p.write_text(p.read_text()+'''\n\n### 2026-11-07 claim refinement, stable paper problem\n\nExpanded executable authority is an opportunity diagnosis, not a contribution by itself. Preserve task-conditioned real predecessor and recurrent successor learning. Current independent action-coordinate candidate benefit is unsupported after two trained revisions; ordinarySAC is the retained shared baseline. Same model's Actor/greedy-Q extraction has different physical behavior, so a value's continuation policy and execution semantics must accompany any proposed improvement. Native final success, paired rescue/regression, all physical/data cost and frozen new conditions remain primary. Writing proceeds on implemented methods and scoped evidence, not contingent on a VERIFIED label.\n''')
p=rp/'paper/CLAIM_MATRIX.md';p.write_text(p.read_text()+f'''\n\n## 2026-11-07 completed-cycle claims\n\n| Claim | Evidence | Status |\n|---|---|---|\n| Omitted legal physical opportunity exists |16 design states,256 reset executions; finite14 vs best fixed12 |LOCAL_PHYSICAL_EVIDENCE|\n| Expanded catalogue caused learned development gain |restricted deployed proposal support also21/24 |NOT_ESTABLISHED|\n| Stable ordinary online learning asset |two independent neural seeds21/24; confirmation {summary} |PRELIMINARY_BASELINE|\n| Reference/offset factor improves policy |20/24 vs flat21 |NOT_SUPPORTED|\n| State-conditioned target chart improves policy |19/24 vs flat21; confirmation in evidence |NOT_SUPPORTED_IN_CURRENT_COMPARISON|\n| Mean-Q deployment is a stronger default |rear-only13/24 vs Actor21 |REJECTED_LOCAL|\n| Necessary front/rear synergy |765010 separately rescued by grasp; no factorial necessity |UNVERIFIED|\n| Independent novel RL contribution |mature precedents; no consistent candidate advantage |UNVERIFIED|\n\nNo unchanged historical scores or sealed tests were relabelled.\n''')
p=rp/'paper/MANUSCRIPT.md';p.write_text(p.read_text()+'''\n\n### Completed online comparison and evidence-driven revision\n\nThe constant coordinate candidate did not outperform the flat policy. We then used only currently observed active-to-refreshed target translation/rotation and legal offsets to define a Gaussian action-relation kernel. For nine replanning actions, the row-normalized matrix `.75I+.25K(s)` transforms residual Actor logits; rule/continue/withdraw/hold and queue-continuation aliases remain isolated. No new learned head, planning query or future outcome is supplied. The413 returned physical target coordinates agree with this construction within4.36e-8m; one failed parameterization is retained. This verifies the interface, not benefit. AGILE and prior action-representation learning already motivate state-dependent action relations; our particular execution-reference construction is a tested hypothesis, not established general novelty.\n\n'''+curves+'\n\n### Frozen natural-condition confirmation\n\n'+ct+f'''\n\nAll final models were fixed before opening765600–631. This is a fresh development-confirmation cohort, not sealed testing. The two SAC models share evaluation scenes and cannot be treated as64 independent samples. Both receive256 common design episodes plus128 own-policy episodes, as do the three first-seed alternatives. Historical retained RL/rule comparisons have distinct inherited budgets; only new trained arms support a matched-budget interpretation.\n\n### Mechanistic controls and limitations\n\nMean-Q on the frozen flat network scores13/24, as does changing only rear extraction while retaining Actor grasp; changing only grasp extraction scores19/24 against Actor21. This identifies a rear policy-extraction failure, but the Q target includes shaped reward/entropy and an Actor continuation, so it does not isolate value calibration alone. Restricting the learned Actor to old proposal support retains21/24; the expanded catalogue's causal necessity for this gain is not established. The chart candidate loses765416 by missing an early useful Y+ Option under an identical68-step prefix; its more accurate geometry does not ensure better policy improvement.\n\nThe independent candidate contribution remains unsupported. Ordinary online skill learning is retained as a reproducible baseline; the next methodological problem is execution- and continuation-consistent policy improvement, with matched data and action authority. This cycle contributes actual implemented comparisons, counterexamples and models rather than a new success claim. Total measured cost is{cost['unique_native_episodes']} native episodes and{cost['planning_queries']} planner calls, including startup failures, design and all evaluations. Full evidence, source pins, per-arm costs and two complete physical-state videos are in [the dated release](../evidence/EXP-004/2026-11-07/action_frontier/README.md).\n''')
p=rp/'STATE.json';v=json.loads(p.read_text());v['latest_evidence']='evidence/EXP-004/2026-11-07/action_frontier/README.md';v['latest_run_summary']=f'640 own-policy episodes, five128-episode learners; {cost["unique_native_episodes"]} native episodes total. Frozen confirmation: {summary}. Candidate coordinate sharing not independently better; retain ordinary SAC.';v['next_action']='Read completed action_frontier evidence. Retain full Option runtime, strongest ordinary SAC and all negatives. Do not repeat completed design/training/confirmation. Investigate executed rear Option value versus actual continuation on fresh training prefixes, with actor and Q preference sharing identical physical authority. Expanded catalogue and coordinate sharing alone do not explain deployment gain; no sealed-test use.';v['stage_status']['S5']='completed_action_frontier_cycle; ordinary baseline retained, coordinate candidates unsupported; independent method gain UNVERIFIED';v['action_frontier_20261107']={'status':'COMPLETED','evidence':v['latest_evidence'],'cost':cost,'own_training_episodes':640,'updates':sum(x['updates']for x in tr.values()),'confirmation':{k:{'n':g[k]['n'],'success':g[k]['success']}for k in cs},'seed_status':'32201/32202 actual initial hidden and Q tensors differ; old31901/31902 erratum preserved','candidate_status':'fixed20/24 and state19/24 versus ordinary21/24; no independent benefit demonstrated','next':v['next_action']};p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
p=d/'FROZEN_CONFIRM_PROTOCOL.json';v=json.loads(p.read_text());v['status']='COMPLETED_FIXED_MODELS_NO_RESELECTION';p.write_text(json.dumps(v,indent=2))
print(summary)
