from pathlib import Path
import subprocess,hashlib,json
r=Path('/home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program');d=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107');f='research/skill_handoff_lab/tools/evaluate_full_option.py';variants={}
for rev in ['a52276b','193cc6e','97f6a52']:
 s=subprocess.check_output(['git','show',rev+':'+f],cwd=r).decode();variants[rev]=s
s=variants['193cc6e'];chart=""" d=torch.load(a.model,weights_only=False)
 if d['arm'].startswith('chart_'):
  from train_target_chart_option import Learner as ChartLearner
  m=ChartLearner(assets,32201,d['coordinate'])
 else:m=Learner(assets,32201,d['arm'])
 m.load(d)"""
assert chart in s
variants['proposal_before_chart_dispatch']=s.replace(chart," d=torch.load(a.model,weights_only=False);m=Learner(assets,32201,d['arm']);m.load(d)")
current=(r/f).read_text();variants['current']=current
v4=current.replace('import argparse,torch,json,shutil','import argparse,torch,json').replace("shutil.copy2(__file__,a.out/'evaluate_full_option.py')\n",'');variants['decomposition_before_copy']=v4
variants['old_gate_mask']=v4.replace(",'actor_front_meanq_rear','meanq_front_actor_rear'",'').replace("   if a.extraction=='actor_front_meanq_rear'and s[44]<.5:return m.choose(s)\n",'').replace("   if a.extraction=='meanq_front_actor_rear'and s[44]>=.5:return m.choose(s)\n",'')
out=d/'evaluator_source_versions';out.mkdir(exist_ok=True);saved={}
for label,s in variants.items():
 h=hashlib.sha256(s.encode()).hexdigest();(out/(h+'.py')).write_text(s);saved[h]=label
checks={}
for mf in d.glob('dev_*/MANIFEST.json'):
 m=json.loads(mf.read_text());h=m.get('source')
 if h:checks[str(mf.relative_to(d))]=dict(sha=h,recovered=h in saved)
assert all(x['recovered']for x in checks.values()),checks
(out/'INDEX.json').write_text(json.dumps(dict(versions=saved,manifests=checks),indent=2));print('Recovered exact evaluator sources:',len(checks),'manifests;',len(saved),'unique versions')
