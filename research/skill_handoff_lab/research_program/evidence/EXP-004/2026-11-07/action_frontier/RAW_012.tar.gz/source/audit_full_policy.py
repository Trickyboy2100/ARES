import sys,json,torch,collections,numpy as np
from pathlib import Path
sys.path.insert(0,'research/skill_handoff_lab/tools')
from train_full_option import Learner
from program_rule_option import Assets
from program_full_option import legal
torch.set_num_threads(2);root=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107');assets=Assets();out={}
for arm in ['sac','factor']:
 d=torch.load(root/f'{arm}_32201/CURRENT.pt',weights_only=False);m=Learner(assets,32201,arm);m.load(d['model']);ts=d['data'];own=[t for t in ts if t['episode']>=0];ss=[t['s']for t in own];b,mask=m.context(ss)
 with torch.no_grad():
  x=m.norm(ss);prob=m.probs(x,b,mask,ss);q=torch.stack([v(x)for v in m.q]).mean(0).masked_fill(~mask,-1e9);base=b.masked_fill(~mask,-1e9).argmax(1);act=prob.argmax(1);qa=q.argmax(1)
 out[arm]=dict(own_transitions=len(own),updates=m.updates,actor_vs_initial_argmax_disagreements=int((act!=base).sum()),actor_vs_meanq_disagreements=int((act!=qa).sum()),mean_entropy=float(-(prob*prob.clamp_min(1e-9).log()).sum(1).mean()),chosen_q_mean=float(q.gather(1,act[:,None]).mean()),max_q_mean=float(q.max(1).values.mean()),own_action_counts=dict(collections.Counter(str(t['a']) for t in own)),actor_action_counts=dict(collections.Counter(map(str,act.tolist()))),context_scope='own visited states, not new physical evaluation; argmax comparisons only')
(root/'POLICY_TRAINING_AUDIT.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
