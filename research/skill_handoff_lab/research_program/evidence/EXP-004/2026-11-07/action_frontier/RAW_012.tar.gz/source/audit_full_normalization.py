import sys,torch,numpy as np,json
from pathlib import Path
sys.path.insert(0,'research/skill_handoff_lab/tools')
from program_rule_option import Assets
from train_full_option import Learner
torch.set_num_threads(2);root=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107');m=Learner(Assets(),32201,'sac');d=torch.load(root/'sac_32201/CURRENT.pt',weights_only=False);ss=[t['s']for t in d['data']];z=m.norm(ss).numpy();rank=np.argsort((abs(z)>5).mean(0))[::-1][:12];out=dict(n=len(ss),max_abs=float(abs(z).max()),fraction_gt5=float((abs(z)>5).mean()),fraction_gt10=float((abs(z)>10).mean()),features=[dict(index=int(i),sd=float(m.sd[i]),fraction_gt5=float((abs(z[:,i])>5).mean()),max_abs=float(abs(z[:,i]).max()))for i in rank]);(root/'NORMALIZATION_AUDIT.json').write_text(json.dumps(out,indent=2));print(out)
