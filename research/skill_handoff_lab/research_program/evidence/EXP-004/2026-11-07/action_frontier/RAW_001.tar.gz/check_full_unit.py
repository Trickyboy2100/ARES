import sys
sys.path.insert(0,'research/skill_handoff_lab/tools')
import torch,json
from pathlib import Path
from program_rule_option import Assets
from train_full_option import Learner
from program_full_option import Warm,legal
assets=Assets();a=Learner(assets,32201,'sac');b=Learner(assets,32202,'sac');c=Learner(assets,32201,'factor')
assert not torch.equal(a.actor[0].weight,b.actor[0].weight)
assert not torch.equal(a.q[0][0].weight,b.q[0][0].weight)
assert torch.equal(a.q[0][0].weight,c.q[0][0].weight)
assert torch.linalg.matrix_rank(c.map)==13
root=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107');rows=[]
for p in root.glob('design_*/REPLAY.pt'):rows+=torch.load(p,weights_only=False)
states=[t['s']for e in rows for t in e['ts']]
for s in states:
 assert a.choose(s)==c.choose(s)==a.warm.choose(s)
 assert legal(s)[a.choose(s)]
data=a.decorate([dict(t)for e in rows[:3]for t in e['ts']],-1000);log=a.train(data,2,0);saved=a.state();b.arm='sac';b.load(saved)
assert a.choose(states[0])==b.choose(states[0]);print('PASS distinct initialization; equal cross-arm critics/initial policy; full-rank factor; masks; finite updates; optimizer state restore',len(states))
(root/'UNIT_CHECKS.json').write_text(json.dumps({'distinct_network_seeds':True,'cross_arm_initial_policy_equal':True,'factor_rank':13,'states_checked':len(states),'finite_updates':log,'unit_updates_not_research_training':2},indent=2))
