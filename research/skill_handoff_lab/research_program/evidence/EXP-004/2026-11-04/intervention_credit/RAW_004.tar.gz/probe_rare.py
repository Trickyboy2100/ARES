import sys,json
sys.path.insert(0,'research/skill_handoff_lab/tools')
from program_budget_feedback_sac import FeedbackSAC
from pathlib import Path
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/intervention_credit_20261104');m=FeedbackSAC.load(r.parent/'success_retention_20261104/controlled/FINAL.pt');v=json.loads((r/'current_sac/PAIRS.json').read_text())[0];p=m.probs(m.x([v['s']]))[0].detach().numpy();d=dict(scene=v['scene'],measured_delta=v['delta'],probabilities=p.tolist(),expected_loss_gradient_scale=float(p[v['a']]*(1-p[v['a']])));(r/'RARE_ACTION.json').write_text(json.dumps(d,indent=2));print(d)
