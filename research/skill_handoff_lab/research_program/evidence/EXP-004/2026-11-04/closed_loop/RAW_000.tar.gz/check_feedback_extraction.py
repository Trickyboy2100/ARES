import sys,json,collections
from pathlib import Path
sys.path.insert(0,'research/skill_handoff_lab/tools')
from program_budget_feedback_sac import FeedbackSAC
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/closed_loop_20261104');out={}
for name,path in [('original',r/'train_ordinary_31501/PRETRAIN.pt'),('cql',r/'cql_pretraining/ordinary.pt')]:
 m=FeedbackSAC.load(path);rows=json.loads((r/'train_ordinary_31501/EVAL_0.json').read_text());choices=[m.choose(z['obs'])for row in rows for z in row['decisions']if z['stage']==1];out[name]=dict(rear_actions=dict(collections.Counter(choices)),scope='Counterfactual extraction at already observed states, NOT new policy rollout')
(r/'WARM_EXTRACTION_DIAGNOSTIC.json').write_text(json.dumps(out,indent=2));print(out)
