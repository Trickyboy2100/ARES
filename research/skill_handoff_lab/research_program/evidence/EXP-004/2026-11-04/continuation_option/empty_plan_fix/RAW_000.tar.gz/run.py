import sys,json,shutil
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'research/skill_handoff_lab/tools'))
from program_budget_feedback_sac import FeedbackSAC
from program_peg_feedback import FeedbackRuntime
from program_continuation_option import ContinuationOption
root=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004');out=root/'continuation_empty_fix_20261104'
m=FeedbackSAC.load(root/'continuation_option_20261104/shared_train/consistent_CHECKPOINT_4.pt');ref=FeedbackSAC.load(root/'success_retention_20261104/controlled/FINAL.pt')
rt=FeedbackRuntime(out/'physics');p=ContinuationOption(lambda s:1 if s[44]<.5 else m.choose(s),ref.choose,'insertion_queue');r,t,d=rt.run(758204,p,'shared_empty_success_fix');print(r['success'],r['error'],r['steps'],[(x['phase'],x.get('empty_success_holds'))for x in r['calls']],flush=True);(out/'RESULT.json').write_text(json.dumps(r,indent=2));shutil.copy2('research/skill_handoff_lab/tools/program_peg_feedback.py',out/'program_peg_feedback.py');rt.close()
