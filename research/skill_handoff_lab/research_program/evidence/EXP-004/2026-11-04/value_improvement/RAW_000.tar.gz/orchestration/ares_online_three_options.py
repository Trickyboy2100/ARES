import time,subprocess,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/value_improvement_20261104');root=r/'threeway';py='/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python'
jobs=[(seed,kind)for seed in [31401,31402]for kind in ['sac_mean','handoff_complete','vi_mean']]
(root/'ONLINE_PROTOCOL.json').write_text(json.dumps(dict(methods=['sac_mean','handoff_complete','vi_mean'],seeds=[31401,31402],scenes=list(range(752100,752132)),episodes_each=32,native_horizon=100,updates_per_episode=25,checkpoints=[0,16,32],hypothesis='coverage-complete measured handoff backup after shared mean-Q value improvement; not claimed novel',timing='declared before viewing three-option development outcomes; motivated by two-option negative result',scope='actual own-policy physical interaction, identical action/observation/controller authority'),indent=2))
def run(job):
 seed,kind=job;folder=root/(f'train_complete_{seed}'if kind=='handoff_complete'else f'train_{seed}');model=folder/f'{kind}_288.pt'
 while not model.exists():time.sleep(5)
 # Avoid opening a file while torch.save still writes it.
 time.sleep(2)
 out=root/f'online_{kind}_{seed}'
 with (root/f'online_{kind}_{seed}.log').open('w')as f:
  subprocess.run(['bash','research/skill_handoff_lab/tools/handoff_offline.sh',py,'research/skill_handoff_lab/tools/run_option_improvement_online.py','--prior','/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/peg_value_20261103','--design',str(r/'extended_design/TRANSITIONS.json'),'--checkpoint',str(model),'--out',str(out)],stdout=f,stderr=subprocess.STDOUT,check=True)
with ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,jobs))
(root/'ONLINE_COMPLETE').write_text('Six real32-episode own-policy learning runs complete.\n')
