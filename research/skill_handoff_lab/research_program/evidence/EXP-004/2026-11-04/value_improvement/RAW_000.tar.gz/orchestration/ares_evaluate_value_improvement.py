import json,time,subprocess
from pathlib import Path
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/value_improvement_20261104');py='/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python'
for mode,count,base in [('two',192,r),('three',288,r/'threeway')]:
 while True:
  try:
   dev=r/('development'if mode=='two'else'extended_development')
   if (base/'TRAINING_COMPLETE').exists()and len(json.loads((dev/'ROWS.json').read_text()))==count:break
  except (FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(5)
 for split in ['design','development']:
  panel=r/((split if mode=='two'else'extended_'+split));out=base/f'eval_{split}'
  with (base/f'eval_{split}.log').open('w')as f:
   subprocess.run(['bash','research/skill_handoff_lab/tools/handoff_offline.sh',py,'research/skill_handoff_lab/tools/eval_option_improvement.py','--root',str(base),'--panel',str(panel),'--out',str(out)],stdout=f,stderr=subprocess.STDOUT,check=True)
 (base/'EVALUATION_COMPLETE').write_text('Frozen checkpoints evaluated on real finite physical branches; not extra rollouts.\n')
