import json,time,subprocess
from pathlib import Path
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/value_improvement_20261104');out=r/'threeway';out.mkdir(exist_ok=True)
while True:
 try:
  rows=json.loads((r/'extended_design/ROWS.json').read_text());ts=json.loads((r/'extended_design/TRANSITIONS.json').read_text())
  if len(rows)==288 and len(set(t['source']for t in ts))==288:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
cmd=['bash','research/skill_handoff_lab/tools/handoff_offline.sh','/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python','research/skill_handoff_lab/tools/train_option_improvement.py','--prior','/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/peg_value_20261103','--data',str(r/'extended_design/TRANSITIONS.json'),'--successor-actions','3']
for seed in [31401,31402]:
 with (out/f'train_{seed}.log').open('w')as f:subprocess.run(cmd+['--out',str(out/f'train_{seed}'),'--seed',str(seed)],stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'TRAINING_COMPLETE').write_text('Both predeclared seeds,11 methods,3 successor actions.\n')
