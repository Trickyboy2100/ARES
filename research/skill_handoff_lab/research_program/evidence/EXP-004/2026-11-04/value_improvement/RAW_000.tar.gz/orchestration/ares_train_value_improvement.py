import json,time,subprocess
from pathlib import Path
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/value_improvement_20261104')
while True:
 try:
  if len(json.loads((r/'design/ROWS.json').read_text()))==192:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
cmd=['bash','research/skill_handoff_lab/tools/handoff_offline.sh','/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python','research/skill_handoff_lab/tools/train_option_improvement.py','--prior','/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/peg_value_20261103','--data',str(r/'design/TRANSITIONS.json')]
for seed in [31401,31402]:
 with (r/f'train_{seed}.log').open('w')as f:subprocess.run(cmd+['--out',str(r/f'train_{seed}'),'--seed',str(seed)],stdout=f,stderr=subprocess.STDOUT,check=True)
(r/'TRAINING_COMPLETE').write_text('Both predeclared seeds, all methods final checkpoints saved.\n')
