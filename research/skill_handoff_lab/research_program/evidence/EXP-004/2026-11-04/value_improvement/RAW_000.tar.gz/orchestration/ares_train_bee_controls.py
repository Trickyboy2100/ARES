import json,time,subprocess
from pathlib import Path
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/value_improvement_20261104');py='/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python'
for mode,count,root,data in [('two',192,r,r/'design/TRANSITIONS.json'),('three',288,r/'threeway',r/'extended_design/TRANSITIONS.json')]:
 while True:
  try:
   if len(set(t['source']for t in json.loads(data.read_text())))==count:break
  except(FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(5)
 for seed in [31401,31402]:
  with (root/f'bee_{seed}.log').open('w')as f:
   subprocess.run(['bash','research/skill_handoff_lab/tools/handoff_offline.sh',py,'research/skill_handoff_lab/tools/train_option_improvement.py','--prior','/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/peg_value_20261103','--data',str(data),'--out',str(root/f'train_bee_{seed}'),'--methods','bee','--seed',str(seed),'--successor-actions',str(2 if mode=='two'else 3)],stdout=f,stderr=subprocess.STDOUT,check=True)
 (root/'BEE_COMPLETE').write_text('Equal-data BEE functional controls complete.\n')
