#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
while ! python -c "import json; assert len(json.load(open('$out/identity_dev_fixed1/RESULTS.json')))==16; assert len(json.load(open('$out/paired_reference/RESULTS.json')))==32" 2>/dev/null; do sleep 5; done
sleep 3
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/train_joint_paired_return.py --out "$out/paired_sac_32101" --arm sac --layout flat --seed 32101 --episodes 32 --train-start 764700 --dev-start 764600 --references "$out/paired_reference"
