#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
while ! python -c "import json; assert len(json.load(open('$out/frozen_CHECKPOINT_64/RESULTS.json')))==32" 2>/dev/null; do sleep 5; done
sleep 3
for seed in 31901 31902; do
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/train_joint_continuation.py --out "$out/sac_$seed" --arm sac --seed "$seed"
done
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/run_rule_controls.py --out "$out/dev_rule" --start 764300 --count 16
