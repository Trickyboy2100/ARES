#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
while ! python -c "import json; assert len(json.load(open('$out/dev_rule/RESULTS.json')))==16" 2>/dev/null; do sleep 5; done
sleep 3
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/train_execution_joint.py --out "$out/identity_flat_32001" --layout flat --seed 32001 --train-start 764200 --dev-start 764600
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/run_rule_controls.py --out "$out/identity_dev_rule" --start 764600 --count 16
