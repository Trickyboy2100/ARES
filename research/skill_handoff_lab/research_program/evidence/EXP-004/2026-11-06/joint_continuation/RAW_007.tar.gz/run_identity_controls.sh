#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
old=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/rule_option_20261105
while [ ! -f "$out/identity_semantic_32001/CHECKPOINT_64.pt" ]; do sleep 5; done
sleep 3
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/evaluate_rule_gate.py --out "$out/identity_dev_single_warm" --model "$old/v2_stopping_rl_31801/INITIAL.pt" --start 764600 --count 16
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/run_rule_controls.py --out "$out/identity_dev_fixed1" --start 764600 --count 16 --front 1
