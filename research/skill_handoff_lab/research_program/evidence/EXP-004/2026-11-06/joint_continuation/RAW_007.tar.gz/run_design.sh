#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
old=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/rule_option_20261105
for grasp in 0 1 2; do
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/run_rule_controls.py --out "$out/design_rule_g$grasp" --start 764000 --count 16 --front "$grasp"
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/evaluate_rule_gate.py --model "$old/v2_stopping_rl_31801/INITIAL.pt" --out "$out/design_warm_g$grasp" --start 764000 --count 16 --front "$grasp"
done
