#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
old=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/rule_option_20261105
while ! python -c "import json; assert len(json.load(open('$out/identity_dev_rule/RESULTS.json')))==16" 2>/dev/null; do sleep 5; done
sleep 3
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/evaluate_rule_gate.py --out "$out/frozen_rehearsal" --model "$old/v2_supervised_replay_31801/CHECKPOINT_64.pt" --start 764400 --count 32
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/probe_joint_alias.py --out "$out/alias_probe" --run "$out/sac_31901"
