#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
while [ ! -f "$out/return_mix_31902/CHECKPOINT_64.pt" ]; do sleep 5; done
sleep 3
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/train_execution_joint.py --out "$out/identity_semantic_32001" --layout semantic --seed 32001 --train-start 764200 --dev-start 764600
