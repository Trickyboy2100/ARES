#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
py=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
out=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/joint_continuation_20261106
while [ ! -f "$out/alias_probe/CHECKS.json" ]; do sleep 5; done
sleep 3
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/evaluate_execution_joint.py --model "$out/identity_flat_32001/INITIAL.pt" --out "$out/paired_reference" --start 764700 --count 32
bash research/skill_handoff_lab/tools/handoff_offline.sh "$py" research/skill_handoff_lab/tools/train_joint_paired_return.py --out "$out/paired_pg_32101" --arm paired_pg --layout flat --seed 32101 --episodes 32 --train-start 764700 --dev-start 764600 --references "$out/paired_reference"
