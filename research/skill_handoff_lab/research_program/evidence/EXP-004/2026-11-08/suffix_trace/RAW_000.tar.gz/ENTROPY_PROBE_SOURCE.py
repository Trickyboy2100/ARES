import torch,json,numpy as np
from pathlib import Path
from suffix_trace_learner import Learner
from program_rule_option import Assets
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/suffix_trace_20261108');torch.set_num_threads(2);assets=Assets();out={}
for name in ['sac_32401','trace_32401']:
 d=torch.load(r/name/'CURRENT.pt',weights_only=False);m=Learner(assets,32401,'trace');m.load(torch.load(r/name/'CHECKPOINT_32.pt',weights_only=False));rows=[t for t in d['data']if 'mu'in t and t['policy_episode']<32];ss=[t['next']for t in rows]
 with torch.no_grad():p=m.evaluation_probs(ss);h=-(p*p.clamp_min(1e-9).log()).sum(1).numpy()
 by={}
 for t,e in zip(rows,h):
  if not t['done']:by[t['policy_episode']]=by.get(t['policy_episode'],0)+.01*float(e)
 out[name]={'average_future_entropy_bonus_sum':float(np.mean(list(by.values()))),'max_sum':max(by.values()),'mean_entropy':float(h.mean()),'mean_rear_duration':float(np.mean([t['duration']for t in rows if t['stage']==1]))}
print(json.dumps(out,indent=2));(r/'ENTROPY_SCOPE_PROBE.json').write_text(json.dumps(out,indent=2))
