from pathlib import Path
import torch,json
from suffix_trace_learner import Learner
from program_rule_option import Assets
r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/suffix_trace_20261108');torch.set_num_threads(2);assets=Assets();out=[]
for seed in [769400,769401]:
 d=torch.load(r/'trace_32401'/f'PENDING_{seed-769400:04d}.pt',weights_only=False)
 ts=[t for t in d['ts']if t['stage']==1];t=ts[1]if seed==769400 else ts[0];s=t['s']
 for arm in ['sac','trace','lagged']:
  p=r/f'{arm}_32401/CHECKPOINT_32.pt'
  if not p.exists():continue
  m=Learner(assets,32401,arm);m.load(torch.load(p,weights_only=False));b,mask=m.context([s])
  with torch.no_grad():pr=m.probs(m.norm([s]),b,mask,[s])[0];q=torch.stack([v(m.norm([s]))for v in m.q]).mean(0)[0]
  out.append(dict(seed=seed,arm=arm,source_action=t['a'],actor=int(pr.argmax()),source_p=float(pr[t['a']]),actor_p=float(pr.max()),source_q=float(q[t['a']]),actor_q=float(q[pr.argmax()]),q_argmax=int(q.masked_fill(~mask[0],-1e9).argmax()),scope='recorded initial-policy state; not assumed visited by every final policy'))
(r/'ADOPTION32_PROBE.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
