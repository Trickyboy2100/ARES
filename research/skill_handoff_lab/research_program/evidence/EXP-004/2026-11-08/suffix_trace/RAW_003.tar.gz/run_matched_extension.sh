#!/usr/bin/env bash
set -euo pipefail
TOOLS=research/skill_handoff_lab/tools
PY=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
RUN=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/suffix_trace_20261108
INITIAL=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/sac_32202/CURRENT.pt
for mode in trace sac; do
 bash "$TOOLS/handoff_offline.sh" "$PY" "$TOOLS/train_suffix_trace.py" --out "$RUN/${mode}_32401" --initial "$INITIAL" --mode "$mode" --resume >> "$RUN/${mode}_32401.log" 2>&1
done
