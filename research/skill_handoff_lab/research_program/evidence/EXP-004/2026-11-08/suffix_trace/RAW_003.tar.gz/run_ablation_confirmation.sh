#!/usr/bin/env bash
set -euo pipefail
TOOLS=research/skill_handoff_lab/tools
PY=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
RUN=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/suffix_trace_20261108
for arm in sac trace; do
 bash "$TOOLS/handoff_offline.sh" "$PY" "$TOOLS/evaluate_continuation.py" --freeze-front --out "$RUN/confirm_zero_$arm" --mode learned --model "$RUN/ablation/${arm}_32401/CHECKPOINT_32.pt" --start 769600 --count 24 > "$RUN/confirm_zero_$arm.log" 2>&1
done
