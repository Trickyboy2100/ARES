#!/usr/bin/env bash
set -euo pipefail
RUN=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/suffix_trace_20261108
E=research/skill_handoff_lab/research_program/evidence/EXP-004/2026-11-08/suffix_trace
readarray -t paths < <(python -c 'import json,sys;d=json.load(open(sys.argv[1]));print(d["left"]);print(d["right"])' "$RUN/VIDEO_SELECTION.json")
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/render_peg_skill_pair.py --left "${paths[0]}" --right "${paths[1]}" --out "$E/video_769400" --left-title 'Inherited strong SAC | native SUCCESS' --right-title 'Retrace after64 own episodes | native FAILURE' --comparison-title '769400: strong-policy regression; measured state replay, not new physics' > "$RUN/video.log" 2>&1
