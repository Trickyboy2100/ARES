#!/usr/bin/env bash
set -euo pipefail
TOOLS=research/skill_handoff_lab/tools
PY=/home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python
RUN=/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/suffix_trace_20261108
slot="$1"
if [[ "$slot" == 0 ]]; then
 for arm in sac trace lagged; do
  bash "$TOOLS/handoff_offline.sh" "$PY" "$TOOLS/evaluate_continuation.py" --freeze-front --out "$RUN/confirm_$arm" --mode learned --model "$RUN/${arm}_32401/CHECKPOINT_64.pt" --start 769600 --count 24 > "$RUN/confirm_$arm.log" 2>&1
 done
else
 bash "$TOOLS/handoff_offline.sh" "$PY" "$TOOLS/evaluate_continuation.py" --freeze-front --out "$RUN/confirm_prior" --mode learned --model /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/sac_32202/CHECKPOINT_128.pt --start 769600 --count 24 > "$RUN/confirm_prior.log" 2>&1
 for mode in fixed5 rule; do
  bash "$TOOLS/handoff_offline.sh" "$PY" "$TOOLS/evaluate_continuation.py" --freeze-front --out "$RUN/confirm_$mode" --mode "$mode" --start 769600 --count 24 > "$RUN/confirm_$mode.log" 2>&1
 done
fi
