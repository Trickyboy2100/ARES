import sys,json,gzip,torch
from pathlib import Path
sys.path.insert(0,'research/skill_handoff_lab/tools')
from train_full_option import Learner
from program_rule_option import Assets
torch.set_num_threads(2);r=Path('/home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108');out=[]
for seed in (32301,32302):
 h=json.loads((r/f'sac_{seed}/HISTORY.json').read_text());base={x['row']['seed']:x for x in h if x['kind']=='eval'and x['checkpoint']==0};m=Learner(Assets(),seed,'sac');m.load(torch.load(r/f'sac_{seed}/CHECKPOINT_128.pt',weights_only=False))
 for scene in (768400,768405,768410,768415):
  row=base[scene];d=json.load(gzip.open(row['row']['path'],'rt'));ev=next(x for x in row['events']if x.get('stage')==1 and x['boundary']);s=next(x['obs']for x in d['summary']['decisions']if x['step']==ev['step']);b,mask=m.context([s]);x=m.norm([s])
  with torch.no_grad():q=torch.stack([v(x)for v in m.q]).mean(0)[0];p=m.probs(x,b,mask,[s])[0]
  out.append(dict(network_seed=seed,scene=scene,step=ev['step'],warm_action=ev['a'],warm_success=row['row']['success'],actor=int(p.argmax()),q_rule=float(q[0]),q_warm=float(q[ev['a']]),prob_rule=float(p[0]),prob_warm=float(p[ev['a']]),scope='fixed observed warm decision state; Q is shaped/entropy value, not success probability; no new execution'))
(r/'SAC128_VALUE_DIAGNOSTIC.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
