from pathlib import Path
import json,hashlib,subprocess,shlex
lab=Path('/home/andyee/robot-research/ARES-Skilllab');repo=lab/'repos/ARES-SCI-program';r=lab/'runs/research_program/EXP-004/continuation_retention_20261108';py=lab/'envs/method-evolution-20261028/bin/python'
h=json.loads((r/'witness_margin_32301/HISTORY.json').read_text());e=[x['row']for x in h if x['kind']=='eval'and x['checkpoint']==64];assert len(e)==16
print('margin64',sum(x['success']for x in e));assert sum(x['success']for x in e)<=10
(r/'MARGIN_DECISION.json').write_text(json.dumps(dict(complete_count=16,success=sum(x['success']for x in e),decision='Retain64 pilot; no extension because predeclared evidence criterion not met; matched64 controls included',no_confirmation_opened=True),indent=2))
items=[]
def add(name,model=None,mode='learned',freeze=True,old=False,budget=128,scope='matched own128 plus shared and current-policy refresh'):
 items.append(dict(name=name,model=str(model)if model else None,model_sha=hashlib.sha256(model.read_bytes()).hexdigest()if model else None,mode=mode,freeze_front=freeze,old=old,own_budget=budget,scope=scope))
for arm in ['sac','retention','ranking','witness_soft','witness_qp']:
 for seed in [32301,32302]:add(f'{arm}_{seed}',r/f'{arm}_{seed}/CHECKPOINT_128.pt')
add('joint_sac_32301',r/'joint_sac_32301/CHECKPOINT_128.pt',freeze=False,scope='Joint front/rear control; different front permission explicitly separated')
for mode in ['warm','rule','fixed5']:add(mode,mode=mode,budget=0,scope='Frozen shared controller; no new training')
add('prior_sac32202',r.parent/'action_frontier_20261107/sac_32202/CHECKPOINT_128.pt',scope='Historical model/different data budget; front frozen here to shared warm, not historical score')
add('old_rl',r.parent/'rule_option_20261105/v2_stopping_rl_31801/CHECKPOINT_64.pt',freeze=False,old=True,budget=64,scope='Historical different single-deviation interface and front; reference only')
for arm in ['witness_margin','sac','witness_soft']:add(f'{arm}_64_32301',r/f'{arm}_32301/CHECKPOINT_64.pt',budget=64,scope='Matched64 exploratory margin ablation, single network seed')
assert not list(r.glob('confirm_*/RESULTS.json'))
manifest=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),seeds=list(range(768600,768632)),selection='Final128 for primary arms, final64 for explicitly separate margin ablation; no development-best checkpoint selection',scope='Fresh natural development confirmation, not sealed test. Freeze all models before any outcomes.',items=items)
(r/'FROZEN_COMPARISON.json').write_text(json.dumps(manifest,indent=2))
for slot,pid in [(0,1945995),(1,1947769)]:
 lines=['#!/bin/bash','set -euo pipefail',f'while [ -d /proc/{pid} ]; do sleep 5; done',f'cd {shlex.quote(str(repo))}']
 for x in items[slot::2]:
  args=['bash','research/skill_handoff_lab/tools/handoff_offline.sh',str(py),'research/skill_handoff_lab/tools/'+('evaluate_rule_gate.py'if x['old']else'evaluate_continuation.py'),'--out',str(r/f"confirm_{x['name']}"),'--start','768600','--count','32']
  if x['model']:args+=['--model',x['model']]
  if not x['old']:args+=['--mode',x['mode']]+(['--freeze-front']if x['freeze_front']else[])
  lines.append(shlex.join(args)+' > '+shlex.quote(str(r/f"confirm_{x['name']}.log"))+' 2>&1')
 (r/f'run_frozen_slot{slot}.sh').write_text('\n'.join(lines)+'\n')
print('frozen',len(items),'models/controllers',len(items)*32,'native episodes')
