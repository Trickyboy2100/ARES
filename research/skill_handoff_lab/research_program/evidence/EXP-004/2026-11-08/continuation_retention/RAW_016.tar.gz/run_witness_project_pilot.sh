#!/bin/bash
set -euo pipefail
while [ -d /proc/1930929 ]; do sleep 5; done
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/train_witness_option.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/witness_project_32301 --shared /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/SHARED.pt --arm witness_project --seed 32301 --stop-after 64 > /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/witness_project_32301.log 2>&1
