#!/bin/bash
set -euo pipefail
while [ -d /proc/1953794 ]; do sleep 5; done
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/retake_charger_prefix_pairs.py --root /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108 > /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/charger_prefix_retakes.log 2>&1
