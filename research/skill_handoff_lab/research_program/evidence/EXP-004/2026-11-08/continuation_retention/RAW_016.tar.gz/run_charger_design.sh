#!/bin/bash
set -euo pipefail
while [ -d /proc/1949800 ]; do sleep 5; done
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/program_native_charger_pace.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/charger_design --seeds 768800 768801 768802 768803 768804 768805 768806 768807 768808 768809 768810 768811 --angles 15 30 45 --policies nominal feedback > /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/charger_design.log 2>&1
