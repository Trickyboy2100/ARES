#!/bin/bash
set -euo pipefail
while [ -d /proc/1945051 ]; do sleep 5; done
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/collect_policy_disagreement_pairs.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/disagreement_design --start 768064 --count 32 --freeze-front --proposers /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/sac_32202/CHECKPOINT_128.pt /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/action_frontier_20261107/supervised_32201/CHECKPOINT_128.pt > /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/continuation_retention_20261108/disagreement_design.log 2>&1
