import subprocess,sys,json,hashlib
from pathlib import Path
r=Path(__file__).parent;p=r/'resume_split'
cmd=[sys.executable,'research/skill_handoff_lab/tools/train_option_online.py','--out',str(p),'--arm','sac','--episodes','2','--train-start','758900','--dev-count','0','--updates','4','--resume']
h=lambda:hashlib.sha256((p/'FINAL.pt').read_bytes()).hexdigest()
b=h();x=subprocess.run(cmd,capture_output=True,text=True);assert x.returncode==0 and 'ALREADY_COMPLETE_NO_PHYSICS' in x.stdout,(x.stdout,x.stderr);assert h()==b
z=subprocess.run(cmd+['--seed','999'],capture_output=True,text=True);assert z.returncode!=0 and 'Resume protocol/source/seed mismatch' in z.stderr
out=dict(status='PASS',completed_resume_no_new_physics=True,final_bytes_unchanged=True,changed_seed_rejected=True,audited_v1_v2_metadata_migration=True)
(r/'RESUME_GUARDS.json').write_text(json.dumps(out,indent=2));print(out)
