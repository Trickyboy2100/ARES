import json,gzip,torch,numpy as np
from pathlib import Path
r=Path(__file__).parent
x=[]
for name in ['resume_full','resume_split']:
 p=r/name;cur=json.loads((p/'CURRENT.json').read_text());x.append(torch.load(p/cur['checkpoint'],weights_only=False))
def eq(a,b):
 if isinstance(a,torch.Tensor):return torch.equal(a,b)
 if isinstance(a,np.ndarray):return np.array_equal(a,b)
 if isinstance(a,dict):return a.keys()==b.keys() and all(eq(a[k],b[k]) for k in a)
 if isinstance(a,(tuple,list)):return len(a)==len(b) and all(eq(v,w)for v,w in zip(a,b))
 return a==b
assert eq(x[0]['model']['weights'],x[1]['model']['weights'])
assert eq(x[0]['model']['rng'],x[1]['model']['rng']) and eq(x[0]['global_rng'],x[1]['global_rng'])
for a,b in zip(x[0]['data'],x[1]['data']):assert eq({k:v for k,v in a.items() if k!='source'},{k:v for k,v in b.items() if k!='source'})
for a,b in zip(x[0]['records'],x[1]['records']):
 with gzip.open(a['row']['path'],'rt')as f:da=json.load(f)
 with gzip.open(b['row']['path'],'rt')as f:db=json.load(f)
 assert da['initial']==db['initial'] and da['steps']==db['steps']
assert len(list((r/'resume_split/physics').glob('*.json.gz')))==2
z=dict(status='PASS',scope='two native100 episodes; interruption after durable collection before update',all_network_and_optimizer_tensors_equal=True,global_and_replay_rng_equal=True,physical_steps_exactly_equal=200,transitions_equal_except_source_path=True,duplicate_reexecutions=0,limits='Mid-PhysX crashes are not restored; uncommitted START is explicitly blocked for cost recovery.')
(r/'RESUME_CHECK.json').write_text(json.dumps(z,indent=2));print(z)
