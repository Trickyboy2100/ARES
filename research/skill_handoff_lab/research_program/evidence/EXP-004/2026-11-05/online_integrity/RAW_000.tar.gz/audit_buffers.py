import json,gzip,torch,hashlib
from pathlib import Path
r=Path(__file__).parent
out={}
for name in ['online_sac','online_success_bc']:
 p=r/name;pointer=json.loads((p/'CURRENT.json').read_text());s=torch.load(p/pointer['checkpoint'],weights_only=False);m=json.loads((p/'MANIFEST.json').read_text());train=set(m['train']);dev=set(m['development']);assert not train&dev
 assert all(t['scene']in train and str(p/'physics')in t['source'] for t in s['data'])
 assert all(t['scene']in train for t in s['labels'])
 scenes={}
 for t in s['data']:scenes[t['scene']]=scenes.get(t['scene'],0)+t['duration']
 assert len(scenes)==64 and set(scenes.values())=={100}
 assert all(0<=t['a']<(3 if t['stage']==0 else 8) for t in s['data'])
 out[name]=dict(native_training_episodes=64,steps=sum(scenes.values()),transitions=len(s['data']),labels=len(s['labels']),no_dev_replay=True,no_other_arm_replay=True,legal_actions=True,checkpoint_sha=hashlib.sha256((p/pointer['checkpoint']).read_bytes()).hexdigest())
old=json.loads((r/'remaining_plan/RESULTS.json').read_text());new=json.loads((r/'refresh_only/RESULTS.json').read_text());count=0
for x in new:
 if x['intervention']:continue
 y=next(z for z in old if z['intervention']==0 and z['seed']==x['seed'] and z['grasp']==x['grasp'])
 dx=json.load(gzip.open(x['path'],'rt'));dy=json.load(gzip.open(y['path'],'rt'));assert dx['initial']==dy['initial'] and dx['steps']==dy['steps'];count+=1
out['nominal_repeats_exact']=count;out['nominal_repeat_physical_steps']=count*100
(r/'BUFFER_AUDIT.json').write_text(json.dumps(out,indent=2));print(out)
