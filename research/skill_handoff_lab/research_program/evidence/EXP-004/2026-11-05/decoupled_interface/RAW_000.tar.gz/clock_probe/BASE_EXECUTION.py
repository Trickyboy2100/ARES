def execute_feedback(self,planner,pose,*args,**kw):
    from mani_skill.utils.structs.pose import to_sapien_pose
    pose=to_sapien_pose(pose)
    e=self.env;u=e.unwrapped;phase=['REACH','GRASP','ALIGN','REFINE1','REFINE2','REFINE3','INSERT'][min(len(e.calls),6)];e.phase=phase;call=dict(phase=phase,start=len(e.records),target=np.r_[pose.p,pose.q].tolist());e.calls.append(call)
    def plan(target):
        for _ in range(2):
            result=planner.planner.plan_screw(np.r_[target.p,target.q],u.agent.robot.get_qpos().cpu().numpy()[0],time_step=u.control_timestep,use_point_cloud=planner.use_point_cloud)
            if result['status']=='Success':
                positions=np.array(result['position'])
                if len(positions):return positions
                # A successful zero-length planner result has no next joint
                # command. Measure and execute one hold step, preserving the
                # native budget, rather than indexing queue[-1] or inventing
                # a target configuration. Recorded separately from RL gain.
                call['empty_success_holds']=call.get('empty_success_holds',0)+1
                return np.array([val(u.agent.robot.get_qpos()[0,:7])])
        return None
    queue=plan(pose);nominal_failed=queue is None;cursor=0;last=0;holdq=None
    active_target=pose
    if nominal_failed and self.correction_frame=='remaining_target':
        active_target=u.agent.tcp.pose.sp
    if queue is None:queue=np.array([val(u.agent.robot.get_qpos()[0,:7])])
    while len(e.records)<100:
        obs=features(e.measure(),100-len(e.records),1,queue,cursor,last);obs[49]=min(len(e.calls),7)/7
        # Read-only evidence captured BEFORE the intervention; not a PhysX
        # checkpoint and never used to reset or alter the execution.
        before=dict(queue=np.asarray(queue).tolist(),cursor=cursor,last=last,
                    nominal_failed=nominal_failed,
                    holdq=None if holdq is None else holdq.tolist(),phase=phase)
        action=self.decide(obs);record=self.actions[-1];record['plan_failed']=False;record['replanned']=False
        record['queue_before']=before
        record['active_target_before']=np.r_[active_target.p,active_target.q].tolist()
        if nominal_failed and action==0:
            call.update(end=len(e.records),failed=True);return -1
        nominal_failed=False
        if action==7:
            queue=np.array([val(u.agent.robot.get_qpos()[0,:7])]);cursor=0;holdq=None
            active_target=u.agent.tcp.pose.sp
        elif action!=0 and not(action in (1,2,3,4,5) and action==last and cursor<len(queue)):
            shift=np.zeros(3)
            if action in (2,3):shift[1]=.003*(1 if action==2 else -1)
            if action in (4,5):shift[2]=.003*(1 if action==4 else -1)
            if phase=='INSERT':target=u.goal_pose.sp*sapien.Pose(shift)*u.peg.pose.sp.inv()*u.agent.tcp.pose.sp*sapien.Pose([.05,0,0])
            else:
                shift[0]=-float(u.peg_half_sizes[0,0])-.01
                target=u.goal_pose.sp*sapien.Pose(shift)*u.peg.pose.sp.inv()*u.agent.tcp.pose.sp
            if action==6:
                world=Rotation.from_quat(np.r_[u.goal_pose.sp.q[1:],u.goal_pose.sp.q[0]]).apply([-.006,0,0]);target=sapien.Pose(u.agent.tcp.pose.sp.p+world,u.agent.tcp.pose.sp.q)
            if self.correction_frame=='remaining_target' and action in (2,3,4,5):
                # Translate the existing queue's requested terminal pose in
                # the goal frame. Preserve its orientation. Still a full
                # replan, NOT a bounded joint/control residual or FK claim.
                shift[0]=0
                world=Rotation.from_quat(np.r_[u.goal_pose.sp.q[1:],u.goal_pose.sp.q[0]]).apply(shift)
                target=sapien.Pose(active_target.p+world,active_target.q)
            record['replanned']=True;new=plan(target);record['target']=np.r_[target.p,target.q].tolist()
            record['requested_target_delta_m']=float(np.linalg.norm(target.p-active_target.p))
            if new is not None:queue=new;cursor=0;holdq=None;active_target=target
            else:record['plan_failed']=True
        record['queue_length']=len(queue);record['queue_cursor']=cursor
        for _ in range(min(self.chunk,100-len(e.records),len(queue)-cursor if phase!='INSERT' else 100)):
            if cursor<len(queue):q=queue[cursor];cursor+=1
            else:
                if holdq is None:holdq=np.array(val(u.agent.robot.get_qpos()[0,:7]))
                q=holdq
            e.phase=phase+'_FEEDBACK';out=e.step(np.r_[q,-1]);planner.elapsed_steps+=1
        last=action
        if phase!='INSERT' and cursor>=len(queue):break
    call['end']=len(e.records);call['failed']=False
    return out
