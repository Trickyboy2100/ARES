"""Archive actual evidence, verify full video/frame contracts and build review."""
import argparse,gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in sorted(a.root.rglob('*')) if p.is_file() and 'video_rescue_draft' not in p.parts];manifest=[]
archive=a.out/'physical_evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for f in files:
  name=str(f.relative_to(a.root));tar.add(f,arcname=name,recursive=False);manifest.append(dict(path=name,bytes=f.stat().st_size,sha256=sha(f)))
with tarfile.open(archive,'r:gz') as tar:
 for item in manifest:
  assert not Path(item['path']).is_absolute() and '..' not in Path(item['path']).parts
  assert hashlib.sha256(tar.extractfile(item['path']).read()).hexdigest()==item['sha256']
(a.out/'ARCHIVE_MANIFEST.json').write_text(json.dumps(dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=manifest),indent=2))
for model in ['models31103','models_residual31103']:
 dest=a.out/'models'/model;dest.mkdir(parents=True,exist_ok=True)
 for f in (a.root/model).iterdir():
  if f.is_file():shutil.copy2(f,dest/f.name)
qa=[]
for name in ['video_rescue','video_replan_regression']:
 out=a.out/name;data=json.loads((out/'DATA.json').read_text());assert data['horizon']==100 and data['fps']==20
 for s in data['series']:
  assert len(s['phase'])==101 and len(s['decisions'])==2
  assert all(len(v)==101 for v in s['signals'].values())
  assert s['signals']['Tool/cube contact proxy (N)'][0] is None
 manifest=json.loads((out/'MANIFEST.json').read_text());assert manifest['physics_steps_added']==0 and manifest['max_state_readback_error']<1e-5
 for kind in ['RAW','ANNOTATED']:
  probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames,r_frame_rate,width,height','-of','json',str(out/(kind+'.mp4'))],text=True))['streams'][0]
  assert int(probe['nb_read_frames'])==101 and probe['r_frame_rate']=='20/1';qa.append(dict(video=name+'/'+kind+'.mp4',sha256=sha(out/(kind+'.mp4')),**probe))
 manifest['outputs']={f.name:sha(f) for f in sorted(out.iterdir()) if f.is_file() and f.name!='MANIFEST.json'};(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
(a.out/'VISUAL_QA.json').write_text(json.dumps(dict(status='PASS',videos=qa,frame_contract='frame0 initial, frame k physical control step k at k/20 s',state_and_signal_checks=True,scope='Programmatic full video QA plus separate human-visible frame/browser inspection; graphics replay adds zero physics'),indent=2))
html='''<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ARES SCI · STAP evidence review</title><style>body{margin:0;background:#edf1f5;color:#172a3a;font:16px/1.65 system-ui}main{max-width:1150px;margin:auto;padding:32px}h1{font-size:34px;line-height:1.3}h2{margin-top:30px}section{background:white;border-radius:12px;padding:24px;margin:20px 0}a{color:#176a9a}video,img{width:100%;border-radius:6px}table{border-collapse:collapse;width:100%}td,th{text-align:left;border-bottom:1px solid #d7e0e7;padding:10px}.tag{background:#17364c;color:white;padding:6px 12px;border-radius:6px;display:inline-block}.note{border-left:5px solid #d69b3a;padding-left:16px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}@media(max-width:750px){.grid{display:block}}small{color:#536579}</style><main>
<span class="tag">ARES · EXP-003 · 2026-11-01</span><h1>真实技能执行之后，<br>重新规划一定更好吗？</h1>
<p>本轮完成独立复算、原始STAP算法核执行、双技能物理模型训练与多轮强控制诊断。<b>224条真实物理执行 / 22400控制步 / 5600优化步</b>。没有新RL方法正结果，也没有实机操作。</p>
<p><a href="README.md">完整研究结论</a> · <a href="STAP_MAPPING.md">STAP对应与边界</a> · <a href="analysis/EPISODES.csv">逐例数据和成本</a> · <a href="REPRODUCE.md">复现</a> · <a href="ARCHIVE_MANIFEST.json">原始包SHA</a> · <a href="VISUAL_QA.json">视频验收</a></p>
<section><h2>01 · 最重要的结果</h2><table><tr><th>方法 / 控制</th><th>完整任务成功</th><th>解释</th></tr><tr><td>最强追加固定参数</td><td>4 / 8</td><td>100mm grasp，−65mm hook；开发控制</td></tr><tr><td>普通Fitted Q / Foresight类比</td><td>3 / 8；3 / 8</td><td>同64条真实数据；单训练seed</td></tr><tr><td>STAP原计划 / 实测后验重规划</td><td>6 / 8 → 3 / 8</td><td>完全相同前段，3退化、0救回</td></tr><tr><td>后验重规划 + 预算保护</td><td>4 / 8</td><td>确定性强控制增益，不是RL创新</td></tr><tr><td>增量状态模型：原计划 / 重规划</td><td>4 / 8；3 / 8</td><td>预测更准，任务收益未改善</td></tr></table>
<p class="note">只有两个训练scene、两个新开发scene和一个训练seed。STAP是既有方法主对标；6/8不能作为ARES原创贡献。所有结果保留失败与不同native/task判据。大CEM随机流未严格配对的探索另列，未混入因果消融。</p></section>
<section><h2>02 · 相同前段，后验修正造成退化</h2><p>左：保留合法原计划；右：使用实测SkillResult重新选择hook。两个真实前段逐记录相等。选择不同hook后，几何yaw与执行耗时改变，右侧未在100步内完成拉动。</p><video controls preload="metadata" poster="video_replan_regression/ANNOTATED_100.png" src="video_replan_regression/ANNOTATED.mp4"></video><p><a href="video_replan_regression/SYNC_VIEWER.html">打开逐帧联动审查 →</a> · <a href="video_replan_regression/RAW.mp4">完整原版</a> · <a href="video_replan_regression/TRACE.png">独立机制曲线</a> · <a href="video_replan_regression/CAPTION.md">学术图注</a></p><small>MEASURED_POSE_REPLAY：从真实物理轨迹重渲染，零新增物理步。彩框是实测cube几何投影，黄圈是声明目标容差，不是接触力标记。</small></section>
<section><h2>03 · 也保留真实救回，避免只挑失败</h2><video controls preload="metadata" poster="video_rescue/ANNOTATED_100.png" src="video_rescue/ANNOTATED.mp4"></video><p><a href="video_rescue/SYNC_VIEWER.html">打开逐帧联动审查 →</a> · <a href="video_rescue/RAW.mp4">完整原版</a> · <a href="video_rescue/TRACE.png">独立机制曲线</a> · <a href="video_rescue/CAPTION.md">学术图注</a></p><p>初始pilot中STAP救回一例。但后续固定参数控制亦能达到4/8，不能把这一个案例当独立方法增益。</p></section>
<section><h2>04 · 参数、模型与真实物理后果</h2><a href="analysis/PHYSICAL_PARAMETER_MATRIX.png"><img src="analysis/PHYSICAL_PARAMETER_MATRIX.png" alt="Actual physical parameter matrix"></a><p>每格为一次真实执行，不是价值模型预测。固定105mm/−55mm在训练上下文中全部成功；目前尚未证明抓点需要随任务改变。</p><div class="grid"><a href="analysis/DYNAMICS_ERROR.png"><img src="analysis/DYNAMICS_ERROR.png" alt="Dynamics error"></a><a href="analysis/POSTERIOR_ABLATION.png"><img src="analysis/POSTERIOR_ABLATION.png" alt="Paired posterior ablation"></a></div><p>DATA_DERIVED_PLOT。状态增量预测减少位置误差，但没有改善完整任务成功。后验价值校准和执行预算需分别解决。</p></section>
<section><h2>05 · 下轮只回答一个可反证的问题</h2><p>在补足真实后段动作覆盖、冻结强控制和普通RL之后，合同裕量辅助学习能否正确决定“保留原计划还是修正参数”？必须超过STAP序列、确定性预算保护和同容量普通价值学习。先做96条上限的训练场景干预；不存在条件依赖就调整物理任务，不增加网络模块凑创新。</p><p><a href="INDEPENDENT_AUDIT.json">历史独立统计复算</a> · <a href="kernel/RESULTS.json">12组原始STAP/移植精确核对</a> · <a href="PAIRED_PREFIX_AUDIT.json">前段物理完全一致核对</a> · <a href="physical_evidence.tar.gz">完整本轮物理与模型包</a></p></section></main></html>'''
(a.out/'REVIEW.html').write_text(html)
print(json.dumps(dict(archive_bytes=archive.stat().st_size,files=len(files),videos=len(qa))))
