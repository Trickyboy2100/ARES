# ARES SCI 下一轮自主研究任务书：从能力保持迈向可救回的技能适应

**核查起点：** `Trickyboy2100/ARES`，`research-sci-program`，提交 `9a66e940af443f56a4f158f1f37956f9658fd7fb`（2026-11-05）。如果执行前 HEAD 更新，以新证据优先；禁止覆盖既有轨迹。  
**研究目标：** 单篇 SCI 强化学习方法论文——在保留强名义技能的前提下，使策略能够利用真实执行反馈和任务条件，学习**合法、物理有用、按时执行**的多阶段技能参数修正；至少两类不同物理接触任务。  
**本轮导向：** 实际实现、真实 PhysX 训练和因果实验，而非独立审计、命名新 loss、再次写漂亮计划。Codex 可以读文献、复现实验、改变候选、选择训练方案、理论分析，并在有证据时自主调整优先级。凡称“方法收益”须与成熟强参照明确比较，不要求每个阶段都获得正结果，也不靠全局 `VERIFIED` 门槛限制写作和探索。

## 1. 必读与已经成立的事实

先读根/Scoped `AGENTS.md`、`research/skill_handoff_lab/research_program/{README.md,STATE.json,PAPER_CONTRACT.md,DECISIONS.md,EVIDENCE_LEDGER.md}` 和活动 EXP-003/004；再读源代码：
- `research/skill_handoff_lab/tools/program_peg_feedback.py`
- `research/skill_handoff_lab/tools/program_continuation_option.py`
- `research/skill_handoff_lab/tools/program_budget_feedback_sac.py`
- `research/skill_handoff_lab/tools/train_option_online.py`
- `research/skill_handoff_lab/research_program/evidence/EXP-004/2026-11-05/decoupled_interface/{README.md,CONFIRMATION_SUMMARY.json,OPTION_OWNERSHIP.json,SCHEDULE_MECHANISM.json,LATE_REPLAN_VALUES.json,PRIOR_ART.md}`
- `research/skill_handoff_lab/research_program/paper/MANUSCRIPT.md`

`9a66e94` 的冻结新 32 自然初态：旧 measured+成功 BC 两重复 14/32、12/32；relative active target+成功 BC 为 17/32、18/32；名义继续 19/32。新接口仅减少回归（5→2，7→1），没有相对名义救回；两个种子共享初始神经权重，第二批 16 是适应性追加，不能当封存证据。旧接口冻结规则 17/32，有一个名义失败救回 `760213`、三例回归；新接口同规则 16/32、0 救回。已见 16 dev 上四格并未证明新接口优势。所有 128 回合续训版本最终 dev 表现回落；不能简单再加更新数。

`759205/grasp1` 第 94 步前缀一致：继续当前队列成功；即使目标零偏移，重新规划也失败。现象说明“整段重新生成”可以造成损伤，但不证明轨迹点数本身是唯一原因。旧队列 cursor8/16、剩余6步、原计划也尚有8个队列点，**不能用 `len(new_queue)>remaining` 这种粗规则作为成功可行性判定**：原计划可能在未执行到最后 waypoint 时已满足物理成功判据。

## 2. 四个关键可反证假设（不可同时假定全对）

### H1：新动作表示削弱了“同一时刻的原子组合干预”

旧 measured 的偏移动作等价于 `refresh(actual_attachment) + δ` 同步执行；新 relative 的动作只做 `active_target+δ`，而 refresh 是单独动作 1。两者在一次 Option 决策下**并非同权限**。新方法可能减少破坏，却失去部分及时救回所需的组合能力；`760213` 是线索，不是证明。

**首要因果试验：** 用旧规则的 `760213` 物理轨迹定位第一次产生救回效果的抓持参数、动作、时间、剩余预算、目标、接触和规划队列。对同一个已记录前缀，分别全原生重执行：
- continue；
- refresh-only；
- local δ-only；
- **atomic refresh+δ（同一反馈边界、一个动作）**；
- 在时间预算允许时的 refresh-then-δ（非原子两次操作）。

确保动作真正执行，不能以离线 pose replay 代替独立 PhysX。早先 witness 是已见开发案例，只作机制研究。若 `760213` 的救回来源并非旧接口的原子组合，应立即修订 H1，而不是强行修改 action dictionary。

### H2：Option 保护继续执行时同时封闭了必要的反馈机会

`ContinuationOption(termination='insertion_queue')` 选了非零动作后，通常不因 REACH/GRASP/ALIGN/REFINE 阶段变化自动重新开放高层策略；主要在 grasp loss 或 INSERT 队列耗尽时重新决策。冻结强规则的原始评估却可在每个反馈 chunk 决策。两者有**时间权限差异**，不能只看动作数相同就声称公平。

**首要因果试验：** 逐例报告各策略真正拥有的 decision boundary（物理步、阶段、动作归属 actor/reference、当前队列、剩余预算、接触状态），尤其失败案例；在同一合法物理状态与共同执行器上做现有 `insertion_queue`、成熟的 chunk/phase/event 重开放方式，以及简单保守预算守卫的比较。先用固定策略及真实重执行分离“重新开放是否必要”和“频繁重新开放是否破坏名义成功”；再在有价值的结构上训练策略。事件触发和可学习 Option termination 已有先例，不独立称新。

### H3：整段 replan 扔掉时间进度，而现有局部修正无法保证接触时序

实现一个**标准、最简单且合法**的“以剩余时钟为参照的局部轨迹修正/拼接”参照算子：保留未执行队列进度，从当前实际关节状态连续过渡，仅调整合法未来部分，不偷偷延长100物理步、压缩不满足动力学限制的时间，使用共同IK、关节限位、碰撞和必要的接触安全检查；无法执行则继续旧队列并记录拒绝原因。目标是**可执行性和真实受益**，不是宣称实现了新型轨迹优化理论。

先用 `759205/grasp1` 和新训练初态比较 continue、预算规则、无偏移重规划、普通终点重规划、进度保持修正；需要逐步命令、接触、时间、终态结果。在已见案例成功并不等于泛化。为防只修复“末尾坏操作”，在**原名义失败、存在可执行正修正**的自然训练状态上检查该算子能否真正新增救回。

请自行决定 H1/H2/H3 的小型实验先后，优先检查有直接物理对照和开发成本低的假设。最多同时推进两个工程变量，避免 12 维全组合消融造成解释不清。每个修改都要有版本化 controller ID，旧历史结果永不改写。

### H4：比较结果可能被前驱抓持选择及隐藏执行状态影响

`CONFIRMATION_SUMMARY.json` 披露两策略在同一32自然初态的抓持选择不完全相同：31601 下 measured BC 选择 grasp0/1/2 的次数为14/11/7，relative BC 为7/19/6；31602 下分别为8/24/0与9/22/1。因而新接口带来的最终3/6个净成功变化，**暂不能全部归因于后段执行稳定性**：前驱物理状态不同，是重要中介/混淆解释。另一方面 `features()` 仅提供下一关节命令差、剩余队列比例、cursor、上次动作等摘要，没有完整 `active_target`、`refresh_target-active_target` 或未执行队列；而动作2–5的实际后果依赖它们。这个可执行状态别名可能使策略无法学习何时应刷新和偏移。上述都是待测试机制。

**低成本核查：** 在已经见过的32确认初态上，仅作标注为 posthoc 的固定grasp1及交叉前驱/后继策略对比（必须从合法起点重新物理执行），报告共同抓持下新/旧后继之差、原先自由联合策略之差。新训练时为所有方法提供相同的、真正部署可用的 `active_target` 相对目标/实测参考差和余下计划进度，重新初始化适配新的 obs，并设置“完整信息 + 普通 SAC/成功BC”的强参照。若单是补足状态就解除救回问题，不应把状态拼接命名成原创。

## 3. 最值得优先完成的实际训练能力：在公平权限下获得“救回 + 少退化”

**不要先加新的 critic head、全局 BC 系数搜索或预测头。** 以成熟 SAC 和 SAC+成功BC 为底座。先从 H1 的结果出发，尝试显式原子执行动作集合：

`continue`、`refresh only`、`active-target ±δ`、`atomic refresh+δ`、必要的 withdraw/hold；优先维持 ±Y/Z 原尺度，训练前确定 action schema、同一边界的执行代价和终止条件。旧模式与新模式分别是该候选 action family 的受限子集。若动作数量扩大使探索显著困难，可采用标准分解式 action head/有限选项或有根据的训练课程，但要对成熟基线给予相同权限与预算，不能把分解本身包装成新意。

如果 H2 或 H4 比 H1 更直接，优先改变决定高层**何时可以重新行动**的合法规则或补足共同的可执行状态观测，并同时保留 successful continuation，避免退回每 chunk 随意改规划。所谓 contact/event 信号必须由可部署的实际观测产生，不可使用未来成功真值。

如果 H3 成立，把新的进度保持执行器加入上述候选；此时需比较**同动作空间**下的普通 full-replan 与 progress-consistent 执行。加入 `active_target`、真实队列剩余量/曲线简要、当前 stage/budget 等部署可见信息时，所有对照都获得相同可见特征，重新训练；旧64维策略不要求强行兼容新 obs。禁止拿旧接口转移数据直接改名当成新执行器轨迹。

**训练过程：** 从已经可用的 own-policy/replay/resume 架构继承，优先做有足够失败和恢复机会的合法训练分布；名义成功与失败在数据中均保留，救回/伤害也均采集。训练初态组与开发、最后封存测试严格分离；不能在 `760200–760231` 上反复调方法。早期单种子小验证→实际在线采集和曲线→有正趋势后独立 NN 初始化+随机重复→冻结模型的新组确认。两臂均计真实 episode/控制步/规划查询/Actor和Critic更新；不要求预设固定“1024回合才算验证”，也不能只有几组 scripted paired probe 就宣布方法。

**明确核对学习瓶颈：** 当前 policy 在实际到达的后段状态是否有干预权、有效动作是否被选择、动作实际改变哪些物理量、剩余预算、actor分布及 critic 状态值是否明显矛盾。不要以 Q 分数当成成功概率。128回合后所有 dev 下降的现象需解释（例如策略分布漂移、有效正样本少、过度更新），而非盲目训练更久。

## 4. 机会研究只作为训练设计支撑，不再成为无尽 Gate

选择一批**事先登记且自然采样的训练初态**，记录 nominal successes/failures、是否抵达后段、是否仍可被合法动作改变、最强训练期规则和少量可执行动作的真实成功并集；同一初态不同动作属于成对重复，不视为独立场景。先看已存训练数据与 `760213` 等见证，避免无谓重复物理探索。必要时少量补充训练期的实际同前缀对照。

若当前动作域在绝大多数可抵达失败中都没有物理救回能力，允许 Codex 基于现有任务参数、预先定义的官方合法变化或已有第二任务 PlugCharger 调整实际技能可控参数与任务条件；保留强名义、普通RL和预算。不能为了提高 ours 分数修改官方成功判据、视野权限或只挑有利失败作为最终测试。**任务要有可学、可救回的物理机会，同时不能故意削弱名义控制。**

## 5. 与多阶段论文主干同步进行

前段三个真实 grasp 参数继续由 RL 选，后段实际 SkillResult 用于后续决策；报告 `front fixed / rear learned`、`front learned / rear fixed`、`joint learned` 的必要消融，明确前段的哪个物理结果改变后段可行性，不止是把两个接口放进同一回合。至少准备并小规模实际运行另一个接触机制（优先复用现有 PlugCharger200，强局部 IK servo 为参照），禁止混用其54维连续动作与 Peg64维离散 replay。若第二任务不使用规划队列，应说明共同抽象是**可执行参考、参数和进度**，而非制造不存在的轨迹重启故障。

论文现在继续维护 `MANUSCRIPT.md`，贡献槽位必须按证据拆开：
1. 已有：执行参考刷新的物理含义及其非原子化/重规划风险；
2. 已有初步：分离接口减少部分新初态退化，但开发集不占优且不救回；
3. 本轮争取：真实可学救回，以及具体的动作表达/终止时机/进度一致执行为什么有用；
4. 后续：跨前后技能和第二操作物理机制复用。论文图尽量是可复现的训练曲线、rescue/regression、同前缀执行时间对比和真实跨技能案例。未实现的写 PROPOSED，不靠名字替代机制。

## 6. 必读近邻与版权/科学归因

- MP3 (CoRL 2023)：运动基元与执行中 re-planning；https://arxiv.org/abs/2306.12729
- Option-Critic (AAAI 2017) 和 Learning With Options That Terminate Off-Policy (AAAI 2018)：终止控制、长时 Option 对灵活性的限制；https://ojs.aaai.org/index.php/AAAI/article/view/10916 ，https://ojs.aaai.org/index.php/AAAI/article/view/11740
- Policy Decorator (ICLR 2025)：成熟基座+残差+受控探索；https://policydecorator.github.io/
- Sequential Dexterity (CoRL 2023)、STAP (ICRA 2023)、Recovery Chaining：跨技能条件与可恢复性；https://proceedings.mlr.press/v229/chen23e.html
- From Error Accumulation to Error Contraction (RA-L, August 2026)：原语参数空间预测-残差触发纠正，多阶段任务；https://doi.org/10.1109/LRA.2026.3728324
- ROS 2 轨迹替换文档：某些版本的控制器支持时间锚定的拼接；它是成熟工程参照，不是原创算子；https://control.ros.org/master/doc/ros2_controllers/joint_trajectory_controller/doc/trajectory.html

至少精读最接近两篇正文和实际可用源码，写下“别人做了什么、我们在可执行语义和学习控制上的确切差别”，不是凑引用数量。若最新 prior art 已覆盖候选，积极继承实现，再重新选择最值得研究的细粒度差异。用户不要求算法名必须全新。

## 7. 这一轮必须交付的研究结果与自主权限

1. **至少一个真正的新物理有效动作方案及其同前缀强对照**（若假设被证伪，明确给出替代方案，不只写计划）。
2. **实际 own-policy RL 训练与完整物理主评估**，包括成功率、救回与退化、动作/时间可用性、学习曲线、成本和失败案例；旧历史版本不改。
3. **说明产生结果的机制或否定了哪个解释**，区分“工程公共修复”“成熟方法”“待验证新增贡献”，不要强行把它命名成算法创新。
4. **论文正文更新**：当前已经形成的 Problem、Method、Results、Limitations；可以重命名论文候选但不得扩大未证实主张。
5. **复现与交付**：commit、固定分布、初始模型、真实数据和反例索引、训练 seed、完整模型、SHA、原生步与查询成本；`STATE`、实验卡、`DECISIONS`、`EVIDENCE_LEDGER` 和 `CLAIM_MATRIX` 按实际证据更新，工作区干净时推送研究分支。

允许 Codex 在同一会话内迭代 2–3 次必要的“读论文→修改→真物理→判断→再学习”，无须每步请求同意。也允许发现 H1/H2/H3 不是核心原因后主动改方法；**不能把探索空间缩减为一次性逐项机械打勾，不能只产出下一轮 Gate 文档**。不碰实机、限制现场数据、ARES-R只读，不改基础GPU驱动/环境，其他人的作业进程不动，封存集不用来调方法。

**最终给用户的摘要结构：** 真正获得什么能力 → 比最强成熟方法多了什么/缺少什么 → 物理机制与可复现证据 → 下一轮只差的关键研究问题。
