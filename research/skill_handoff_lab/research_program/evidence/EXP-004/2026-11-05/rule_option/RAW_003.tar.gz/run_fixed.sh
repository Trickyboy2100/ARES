#!/bin/bash
set -euo pipefail
cd /home/andyee/robot-research/ARES-Skilllab/repos/ARES-SCI-program
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_fixed_rule_option.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/rule_option_20261105/dev_first1 --start 763300 --count 16 --proposal 1
bash research/skill_handoff_lab/tools/handoff_offline.sh /home/andyee/robot-research/ARES-Skilllab/envs/method-evolution-20261028/bin/python research/skill_handoff_lab/tools/run_fixed_rule_option.py --out /home/andyee/robot-research/ARES-Skilllab/runs/research_program/EXP-004/rule_option_20261105/confirm_first1 --start 763400 --count 24 --proposal 1
