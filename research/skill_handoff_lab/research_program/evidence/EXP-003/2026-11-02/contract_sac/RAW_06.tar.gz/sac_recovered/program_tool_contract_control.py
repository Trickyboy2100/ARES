"""Shared successor endpoint/arrival correction; native100 goal and dynamics unchanged."""
import sys,time,json
from pathlib import Path
import numpy as np
import program_tool_all_contacts as contacts
run=contacts.run
Parent=run.EffectPlanner
class ContractPlanner(Parent):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);original=self.planner.plan_screw
  def safe(*a,**k):
   try:return original(*a,**k)
   except RuntimeError as exc:
    if str(exc)!='Fail to parameterize path':raise
    self.env.plans.append(dict(phase='SOLVER_FAILURE',step=len(self.env.records),solver='screw_TOPP',error=str(exc)))
    return {'status':'TOPP_PARAMETERIZATION_FAILED'}
  self.planner.plan_screw=safe

 def error(self,q,pose):
  pin=self.planner.pinocchio_model;pin.compute_forward_kinematics(np.r_[q,run.serial(self.robot.get_qpos()[0])[-2:]])
  actual=np.asarray(pin.get_link_pose(self.planner.link_name_2_idx[self.planner.move_group]));goal=np.asarray(self.planner.transform_goal_to_wrt_base(np.r_[pose.p,pose.q]))
  return dict(position_m=float(np.linalg.norm(actual[:3]-goal[:3])),angle_rad=float(2*np.arccos(np.clip(abs(actual[3:]@goal[3:]),0,1))),planned_pose=actual.tolist(),goal=goal.tolist())
 def move_to_pose_with_screw(self,pose,**kwargs):
  if self.env.phase not in ['TRANSFER','HOOK','PULL'] or self.env.effect_mode=='baseline':return super().move_to_pose_with_screw(pose,**kwargs)
  if self.env.effect_mode not in ['corrected','corrected_feedback']:return super().move_to_pose_with_screw(pose,**kwargs)
  start=time.monotonic();q=np.array(run.serial(self.robot.get_qpos()[0]));attempts=[]
  result=self.planner.plan_screw(np.r_[pose.p,pose.q],q,time_step=self.base_env.control_timestep,qpos_step=.01,use_point_cloud=False,wrt_world=True)
  err=None
  if result['status']=='Success' and len(result['position']):err=self.error(result['position'][-1],pose)
  attempts.append(dict(solver='screw_001',status=result['status'],endpoint=err))
  if err is None or err['position_m']>.002 or err['angle_rad']>.02:
   result=self.planner.plan_qpos_to_pose(np.r_[pose.p,pose.q],q,time_step=self.base_env.control_timestep,planning_time=.5,use_point_cloud=False,wrt_world=True)
   err=self.error(result['position'][-1],pose) if result['status']=='Success' and len(result['position']) else None
   attempts.append(dict(solver='qpos_to_pose',status=result['status'],endpoint=err))
  record=dict(phase=self.env.phase,step=len(self.env.records),target=run.rawpose(pose),attempts=attempts,planning_wall_s=time.monotonic()-start,status=result['status'],position=None if err is None else result['position'].tolist(),endpoint_fk=err)
  self.env.plans.append(record)
  if err is None:return -1
  ret=self.follow_path(result,refine_steps=0);holds=[]
  for j in range(5):
   actual=run.sp(self.env.unwrapped.agent.tcp);dp=float(np.linalg.norm(actual.p-pose.p));da=float(2*np.arccos(np.clip(abs(actual.q@pose.q),0,1)));holds.append(dict(step=len(self.env.records),position_m=dp,angle_rad=da))
   if dp<=.004 and da<=.04 or j==4:break
   ret=self.env.step(np.r_[result['position'][-1],self.gripper_state])
  record['arrival']=holds;return ret
original_execute=run.task.execute_chain
def execute(env,*args,**kwargs):
 env.recompute_pull=env.effect_mode=='corrected_feedback';env.pull_limit=.36 if env.recompute_pull else .29
 return original_execute(env,*args,**kwargs)
run.task.execute_chain=execute
run.EffectPlanner=ContractPlanner
if __name__=='__main__':
 try:run.main()
 finally:
  out=Path(sys.argv[sys.argv.index('--out')+1]);(out/Path(__file__).name).write_bytes(Path(__file__).read_bytes());(out/'program_tool_all_contacts.py').write_bytes(Path(contacts.__file__).read_bytes())
